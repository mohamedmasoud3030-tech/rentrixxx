import { useParams, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowRight, User, Phone, Mail, FileText, CheckCircle2, AlertCircle, Key, CreditCard } from "lucide-react";
import { useAppStore } from "@/store";

export default function TenantDetails() {
  const { id } = useParams();
  const { tenants, contracts, invoices, receipts, units, properties } = useAppStore();
  
  const tenant = tenants.find(t => t.id === id);
  
  if (!tenant) {
    return (
      <div className="flex flex-col items-center justify-center h-full space-y-4">
        <h2 className="text-2xl font-bold">المستأجر غير موجود</h2>
        <Link href="/tenants"><Button variant="outline">العودة لقائمة المستأجرين</Button></Link>
      </div>
    );
  }

  // Get all contracts for this tenant
  const tenantContracts = contracts.filter(c => c.tenantId === id);
  const activeContracts = tenantContracts.filter(c => c.status === 'ساري' || c.status === 'قارب على الانتهاء');
  
  // Get financial info
  const tenantInvoices = invoices.filter(i => i.tenantId === id && i.status !== 'ملغاة');
  const tenantReceipts = receipts.filter(r => r.tenantId === id && r.status !== 'ملغي');
  
  const totalInvoiced = tenantInvoices.reduce((sum, i) => sum + i.amount, 0);
  const totalPaid = tenantReceipts.reduce((sum, r) => sum + r.amount, 0);
  const totalDue = Math.max(0, totalInvoiced - totalPaid);

  const overdueInvoices = tenantInvoices.filter(i => i.status === 'متأخر');

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-4">
          <Link href="/tenants">
            <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
              <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-display font-bold text-foreground">{tenant.name}</h1>
            <div className="flex items-center gap-2 mt-1 text-muted-foreground text-sm">
              <span>رقم المستأجر: {tenant.id}</span>
              <span>•</span>
              <Badge variant="secondary" className="font-normal">{tenant.type}</Badge>
              <span>•</span>
              <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${tenant.status === 'نشط' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-muted text-muted-foreground'}`}>
                {tenant.status}
              </span>
            </div>
          </div>
        </div>
        <div className="flex gap-2">
          <Link href={`/contracts?tenant=${tenant.id}`}>
            <Button className="bg-primary text-primary-foreground">عقد جديد</Button>
          </Link>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <Card className="md:col-span-1 border-none shadow-sm h-fit">
          <CardHeader>
            <CardTitle>بيانات التواصل</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-3 text-sm">
              <FileText className="h-4 w-4 text-muted-foreground" />
              <span className="font-medium w-24">الهوية/السجل:</span>
              <span>{tenant.nationalId}</span>
            </div>
            {tenant.contact && tenant.contact !== 'شخصي' && (
              <div className="flex items-center gap-3 text-sm">
                <User className="h-4 w-4 text-muted-foreground" />
                <span className="font-medium w-24">المفوض:</span>
                <span>{tenant.contact}</span>
              </div>
            )}
            <div className="flex items-center gap-3 text-sm">
              <Phone className="h-4 w-4 text-muted-foreground" />
              <span className="font-medium w-24">الجوال:</span>
              <span dir="ltr">{tenant.phone}</span>
            </div>
            {tenant.email && (
              <div className="flex items-center gap-3 text-sm">
                <Mail className="h-4 w-4 text-muted-foreground" />
                <span className="font-medium w-24">البريد:</span>
                <span className="truncate">{tenant.email}</span>
              </div>
            )}

            <div className="pt-4 border-t mt-4">
              <h4 className="font-semibold text-sm mb-3">الملخص المالي</h4>
              <div className="space-y-3">
                <div className="flex justify-between items-center text-sm">
                  <span className="text-muted-foreground">إجمالي المطالبات:</span>
                  <span className="font-bold">{totalInvoiced.toLocaleString()} ﷼</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span className="text-muted-foreground">إجمالي المدفوع:</span>
                  <span className="font-bold text-emerald-600">{totalPaid.toLocaleString()} ﷼</span>
                </div>
                <div className="flex justify-between items-center text-sm pt-2 border-t">
                  <span className="font-medium">الرصيد المستحق:</span>
                  <span className={`font-bold ${totalDue > 0 ? 'text-destructive' : 'text-emerald-600'}`}>
                    {totalDue.toLocaleString()} ﷼
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="md:col-span-2">
          <Tabs defaultValue="contracts" className="w-full">
            <TabsList className="w-full justify-start border-b rounded-none h-auto p-0 bg-transparent mb-6">
              <TabsTrigger value="contracts" className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-6 py-3">
                العقود ({tenantContracts.length})
              </TabsTrigger>
              <TabsTrigger value="financial" className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-6 py-3">
                المدفوعات والمستحقات
              </TabsTrigger>
            </TabsList>

            <TabsContent value="contracts" className="space-y-4">
              {tenantContracts.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground border rounded-lg bg-card">
                  <p>لا توجد عقود مسجلة لهذا المستأجر</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {tenantContracts.map(contract => {
                    const unit = units.find(u => u.id === contract.unitId);
                    const property = unit ? properties.find(p => p.id === unit.propertyId) : null;
                    
                    let statusColor = "bg-muted text-muted-foreground";
                    if (contract.status === "ساري") statusColor = "bg-emerald-500/10 text-emerald-500 border-emerald-200";
                    else if (contract.status === "قارب على الانتهاء") statusColor = "bg-amber-500/10 text-amber-500 border-amber-200";
                    else if (contract.status === "ملغي") statusColor = "bg-destructive/10 text-destructive border-destructive/20";
                    
                    return (
                      <Card key={contract.id} className="border shadow-sm hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <div className="flex flex-col sm:flex-row justify-between gap-4">
                            <div className="flex gap-4">
                              <div className="p-3 bg-primary/10 rounded-lg h-fit">
                                <Key className="h-6 w-6 text-primary" />
                              </div>
                              <div>
                                <div className="flex items-center gap-2 mb-1">
                                  <Link href={`/contracts/${contract.id}`} className="font-bold text-lg hover:underline">
                                    {contract.id}
                                  </Link>
                                  <Badge variant="outline" className={`font-normal ${statusColor}`}>
                                    {contract.status}
                                  </Badge>
                                </div>
                                <div className="text-sm text-muted-foreground">
                                  {unit ? (
                                    <span>{unit.number} - {property?.name || 'عقار غير معروف'}</span>
                                  ) : (
                                    <span>وحدة غير معروفة</span>
                                  )}
                                </div>
                                <div className="text-xs text-muted-foreground mt-2 flex gap-4">
                                  <span>يبدأ: {contract.startDate}</span>
                                  <span>ينتهي: {contract.endDate}</span>
                                </div>
                              </div>
                            </div>
                            <div className="flex flex-col sm:items-end justify-between border-t sm:border-t-0 pt-3 sm:pt-0">
                              <div className="text-left">
                                <p className="font-bold text-lg">{contract.amount.toLocaleString()} ﷼</p>
                                <p className="text-xs text-muted-foreground">{contract.paymentType}</p>
                              </div>
                              <Link href={`/contracts/${contract.id}`}>
                                <Button variant="ghost" size="sm" className="mt-2">التفاصيل</Button>
                              </Link>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              )}
            </TabsContent>

            <TabsContent value="financial" className="space-y-6">
              {overdueInvoices.length > 0 && (
                <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-4 flex items-start gap-3 text-destructive">
                  <AlertCircle className="h-5 w-5 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-bold">تنبيه: مبالغ متأخرة</h4>
                    <p className="text-sm mt-1">يوجد {overdueInvoices.length} فاتورة متأخرة السداد على هذا المستأجر بقيمة إجمالية {overdueInvoices.reduce((s, i) => s + (i.amount - i.paid), 0).toLocaleString()} ﷼.</p>
                  </div>
                </div>
              )}

              <Card className="border shadow-sm">
                <CardHeader className="pb-3 border-b bg-muted/20">
                  <CardTitle className="text-base">الفواتير المستحقة ({tenantInvoices.filter(i => i.status !== 'مدفوع').length})</CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  {tenantInvoices.filter(i => i.status !== 'مدفوع').length === 0 ? (
                    <div className="text-center py-6 text-muted-foreground text-sm">
                      <CheckCircle2 className="h-8 w-8 text-emerald-500/50 mx-auto mb-2" />
                      لا توجد فواتير مستحقة
                    </div>
                  ) : (
                    <div className="divide-y">
                      {tenantInvoices.filter(i => i.status !== 'مدفوع').map(invoice => (
                        <div key={invoice.id} className="p-4 flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-bold">{invoice.id}</span>
                              <Badge variant="outline" className={invoice.status === 'متأخر' ? 'border-destructive text-destructive bg-destructive/10' : 'border-amber-200 text-amber-600 bg-amber-50'}>
                                {invoice.status}
                              </Badge>
                            </div>
                            <div className="text-xs text-muted-foreground flex gap-3">
                              <span>استحقاق: {invoice.dueDate}</span>
                              <span>عقد: {invoice.contractId}</span>
                            </div>
                          </div>
                          <div className="flex items-center gap-4">
                            <div className="text-left">
                              <p className="font-bold text-destructive">{(invoice.amount - invoice.paid).toLocaleString()} ﷼</p>
                              <p className="text-xs text-muted-foreground">من أصل {invoice.amount.toLocaleString()}</p>
                            </div>
                            <Button size="sm" variant="outline">تحصيل</Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card className="border shadow-sm">
                <CardHeader className="pb-3 border-b bg-muted/20">
                  <CardTitle className="text-base">آخر المدفوعات (سندات القبض)</CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  {tenantReceipts.length === 0 ? (
                    <div className="text-center py-6 text-muted-foreground text-sm">
                      لا توجد مدفوعات سابقة
                    </div>
                  ) : (
                    <div className="divide-y">
                      {tenantReceipts.slice(0, 5).map(receipt => (
                        <div key={receipt.id} className="p-4 flex justify-between items-center gap-4">
                          <div className="flex items-center gap-3">
                            <div className="p-2 bg-emerald-500/10 rounded-full">
                              <CreditCard className="h-4 w-4 text-emerald-600" />
                            </div>
                            <div>
                              <div className="font-medium text-sm">{receipt.id}</div>
                              <div className="text-xs text-muted-foreground">{receipt.date} • {receipt.method}</div>
                            </div>
                          </div>
                          <div className="font-bold text-emerald-600">
                            +{receipt.amount.toLocaleString()} ﷼
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}