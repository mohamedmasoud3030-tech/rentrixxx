import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Plus, Search, Filter, MoreHorizontal, Eye, Edit, Trash, Download, Phone, Mail } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useAppStore } from "@/store";
import { Tenant } from "@/types";
import { useToast } from "@/hooks/use-toast";

export default function TenantsList() {
  const { tenants, contracts, addTenant, updateTenant, deleteTenant } = useAppStore();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const [isAddOpen, setIsAddOpen] = useState(false);
  const [formData, setFormData] = useState<Partial<Tenant>>({ type: 'فرد', status: 'نشط' });

  const getTenantStats = (tenantId: string) => {
    const tenantContracts = contracts.filter(c => c.tenantId === tenantId);
    const activeContracts = tenantContracts.filter(c => c.status === 'ساري' || c.status === 'قارب على الانتهاء').length;
    const totalValue = tenantContracts.reduce((sum, c) => sum + c.amount, 0);
    return { activeContracts, totalValue };
  };

  const handleSave = () => {
    if (!formData.name || !formData.phone || !formData.nationalId) {
      toast({ title: "خطأ", description: "الرجاء تعبئة الحقول الأساسية", variant: "destructive" });
      return;
    }
    
    addTenant(formData as Omit<Tenant, 'id'>);
    toast({ title: "نجاح", description: "تمت إضافة المستأجر بنجاح" });
    setIsAddOpen(false);
    setFormData({ type: 'فرد', status: 'نشط' });
  };

  const handleDelete = (id: string) => {
    const tenantContracts = contracts.filter(c => c.tenantId === id);
    if (tenantContracts.length > 0) {
      toast({ title: "لا يمكن الحذف", description: "هذا المستأجر لديه عقود مسجلة", variant: "destructive" });
      return;
    }

    if(confirm("هل أنت متأكد من حذف هذا المستأجر؟")) {
      deleteTenant(id);
      toast({ title: "تم الحذف", description: "تم حذف المستأجر بنجاح" });
    }
  };

  const stats = {
    total: tenants.length,
    active: tenants.filter(t => t.status === 'نشط').length,
    companies: tenants.filter(t => t.type === 'شركة' || t.type === 'مؤسسة').length,
    individuals: tenants.filter(t => t.type === 'فرد').length,
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground">المستأجرين</h1>
          <p className="text-muted-foreground mt-1">إدارة بيانات المستأجرين من أفراد وشركات</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="bg-background">
            <Download className="mr-2 h-4 w-4" />
            تصدير البيانات
          </Button>
          
          <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
            <DialogTrigger asChild>
              <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
                <Plus className="mr-2 h-4 w-4" />
                إضافة مستأجر جديد
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>إضافة مستأجر جديد</DialogTitle>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="name">الاسم الكامل / اسم الشركة</Label>
                  <Input id="name" value={formData.name || ''} onChange={e => setFormData({...formData, name: e.target.value})} />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="type">النوع</Label>
                    <Select value={formData.type} onValueChange={(val: any) => setFormData({...formData, type: val})}>
                      <SelectTrigger>
                        <SelectValue placeholder="اختر النوع" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="فرد">فرد</SelectItem>
                        <SelectItem value="شركة">شركة</SelectItem>
                        <SelectItem value="مؤسسة">مؤسسة</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="nationalId">رقم الهوية / السجل</Label>
                    <Input id="nationalId" value={formData.nationalId || ''} onChange={e => setFormData({...formData, nationalId: e.target.value})} />
                  </div>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="contact">المفوض بالتواصل (للشركات)</Label>
                  <Input id="contact" value={formData.contact || ''} onChange={e => setFormData({...formData, contact: e.target.value})} placeholder="الاسم الشخصي" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="phone">رقم الجوال</Label>
                    <Input id="phone" value={formData.phone || ''} onChange={e => setFormData({...formData, phone: e.target.value})} dir="ltr" className="text-right" />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="email">البريد الإلكتروني</Label>
                    <Input id="email" type="email" value={formData.email || ''} onChange={e => setFormData({...formData, email: e.target.value})} dir="ltr" className="text-right" />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddOpen(false)}>إلغاء</Button>
                <Button onClick={handleSave}>حفظ البيانات</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="border-none shadow-sm bg-card">
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground mb-1">إجمالي المستأجرين</p>
            <p className="text-2xl font-bold">{stats.total}</p>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm bg-card">
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground mb-1">مستأجرين نشطين</p>
            <p className="text-2xl font-bold text-emerald-500">{stats.active}</p>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm bg-card">
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground mb-1">شركات / مؤسسات</p>
            <p className="text-2xl font-bold">{stats.companies}</p>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm bg-card">
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground mb-1">أفراد</p>
            <p className="text-2xl font-bold">{stats.individuals}</p>
          </CardContent>
        </Card>
      </div>

      <Card className="border-none shadow-sm">
        <CardHeader className="pb-3 border-b">
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
            <div className="relative w-full sm:w-96">
              <Search className="absolute right-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="البحث باسم المستأجر، رقم الهوية، الجوال..."
                className="pr-9 bg-muted/50 border-none"
              />
            </div>
            <div className="flex gap-2 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0">
              <Button variant="secondary" size="sm" className="whitespace-nowrap">الكل</Button>
              <Button variant="ghost" size="sm" className="whitespace-nowrap text-muted-foreground">أفراد</Button>
              <Button variant="ghost" size="sm" className="whitespace-nowrap text-muted-foreground">شركات</Button>
              <Button variant="outline" size="icon" className="ml-auto sm:ml-2">
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-right">
              <thead className="bg-muted/30">
                <tr className="border-b">
                  <th className="px-4 py-3 font-medium text-muted-foreground">رقم المستأجر</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">اسم المستأجر</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">النوع</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">بيانات التواصل</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">عقود نشطة</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">إجمالي قيمة العقود</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">الحالة</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground w-[80px]">إجراءات</th>
                </tr>
              </thead>
              <tbody>
                {tenants.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="text-center py-8 text-muted-foreground">لا يوجد مستأجرين</td>
                  </tr>
                ) : tenants.map((tenant) => {
                  let statusColor = "bg-muted text-muted-foreground";
                  if (tenant.status === "نشط") statusColor = "bg-emerald-500/10 text-emerald-500";
                  
                  const tenantStats = getTenantStats(tenant.id);

                  return (
                    <tr 
                      key={tenant.id} 
                      className="border-b last:border-0 hover:bg-muted/20 transition-colors cursor-pointer"
                      onClick={() => setLocation(`/tenants/${tenant.id}`)}
                    >
                      <td className="px-4 py-3 font-medium text-primary">{tenant.id}</td>
                      <td className="px-4 py-3 font-medium">{tenant.name}</td>
                      <td className="px-4 py-3">
                        <Badge variant="outline" className="font-normal bg-background">
                          {tenant.type}
                        </Badge>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex flex-col gap-1">
                          <div className="flex items-center text-xs text-muted-foreground">
                            <Phone className="h-3 w-3 ml-1" />
                            <span dir="ltr">{tenant.phone}</span>
                          </div>
                          <div className="flex items-center text-xs text-muted-foreground">
                            <Mail className="h-3 w-3 ml-1" />
                            <span>{tenant.email}</span>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 font-medium">{tenantStats.activeContracts}</td>
                      <td className="px-4 py-3 font-medium">{tenantStats.totalValue.toLocaleString()} ﷼</td>
                      <td className="px-4 py-3">
                        <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${statusColor}`}>
                          {tenant.status}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <span className="sr-only">فتح القائمة</span>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem className="cursor-pointer">
                              <Eye className="mr-2 h-4 w-4" />
                              <span>عرض الملف</span>
                            </DropdownMenuItem>
                            <DropdownMenuItem className="cursor-pointer">
                              <Edit className="mr-2 h-4 w-4" />
                              <span>تعديل البيانات</span>
                            </DropdownMenuItem>
                            <DropdownMenuItem className="cursor-pointer text-destructive" onClick={() => handleDelete(tenant.id)}>
                              <Trash className="mr-2 h-4 w-4" />
                              <span>حذف</span>
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}