import { useParams, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Gavel, Building2, User, Phone, MapPin, Calendar, Clock, Image as ImageIcon } from "lucide-react";
import { useAppStore } from "@/store";

export default function MaintenanceDetails() {
  const { id } = useParams();
  const { maintenance, properties, units, tenants, contracts } = useAppStore();
  
  const request = maintenance.find(m => m.id === id);
  
  if (!request) {
    return (
      <div className="flex flex-col items-center justify-center h-full space-y-4">
        <h2 className="text-2xl font-bold">طلب الصيانة غير موجود</h2>
        <Link href="/maintenance"><Button variant="outline">العودة لقائمة الطلبات</Button></Link>
      </div>
    );
  }

  const property = properties.find(p => p.id === request.propertyId);
  const unit = request.unitId !== '-' ? units.find(u => u.id === request.unitId) : null;
  
  // Find tenant if unit is occupied
  let tenant = null;
  if (unit) {
    const activeContract = contracts.find(c => c.unitId === unit.id && (c.status === 'ساري' || c.status === 'قارب على الانتهاء'));
    if (activeContract) {
      tenant = tenants.find(t => t.id === activeContract.tenantId);
    }
  }

  let statusColor = "bg-muted text-muted-foreground";
  if (request.status === "مكتمل") statusColor = "bg-emerald-500/10 text-emerald-500 border-emerald-200";
  else if (request.status === "قيد التنفيذ") statusColor = "bg-blue-500/10 text-blue-500 border-blue-200";
  else if (request.status === "مفتوح") statusColor = "bg-amber-500/10 text-amber-500 border-amber-200";
  else if (request.status === "ملغي") statusColor = "bg-destructive/10 text-destructive border-destructive/20 line-through";

  let priorityColor = "text-muted-foreground";
  if (request.priority === "عاجل") priorityColor = "text-destructive";
  else if (request.priority === "متوسط") priorityColor = "text-amber-500";
  else if (request.priority === "منخفض") priorityColor = "text-emerald-500";

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-4">
          <Link href="/maintenance">
            <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
              <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-display font-bold text-foreground">طلب صيانة: {request.id}</h1>
            <div className="flex items-center gap-2 mt-1">
              <Badge variant="outline" className={`font-normal ${statusColor}`}>
                {request.status}
              </Badge>
              <span className="text-muted-foreground text-sm">•</span>
              <span className="text-muted-foreground text-sm">تاريخ الطلب: {request.date}</span>
            </div>
          </div>
        </div>
        <div className="flex gap-2">
          {request.status === 'مفتوح' && (
            <Button className="bg-blue-600 hover:bg-blue-700 text-white">إسناد لفني</Button>
          )}
          {request.status === 'قيد التنفيذ' && (
            <Button className="bg-emerald-600 hover:bg-emerald-700 text-white">إغلاق الطلب</Button>
          )}
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-6">
          <Card className="border-none shadow-sm">
            <CardHeader className="pb-3 border-b">
              <CardTitle>تفاصيل المشكلة</CardTitle>
            </CardHeader>
            <CardContent className="pt-6 space-y-6">
              <div>
                <h3 className="font-bold text-xl mb-2">{request.title}</h3>
                <p className="text-muted-foreground leading-relaxed bg-muted/20 p-4 rounded-lg border">
                  {request.description}
                </p>
              </div>

              <div className="grid sm:grid-cols-2 gap-6">
                <div>
                  <h4 className="text-sm font-semibold text-muted-foreground mb-2 flex items-center gap-2">
                    <Building2 className="h-4 w-4" />
                    الموقع
                  </h4>
                  <div className="font-medium">
                    {property?.name}
                    {unit ? ` - ${unit.number}` : ' - مرافق مشتركة'}
                  </div>
                  {property && (
                    <div className="text-sm text-muted-foreground mt-1 flex items-start gap-1">
                      <MapPin className="h-3.5 w-3.5 mt-0.5 shrink-0" />
                      <span>{property.location}</span>
                    </div>
                  )}
                </div>

                <div>
                  <h4 className="text-sm font-semibold text-muted-foreground mb-2 flex items-center gap-2">
                    <Gavel className="h-4 w-4" />
                    الفني / المقاول المكلف
                  </h4>
                  {request.technician && request.technician !== 'لم يحدد' ? (
                    <div className="font-medium">{request.technician}</div>
                  ) : (
                    <div className="text-amber-600 bg-amber-50 px-3 py-1.5 rounded text-sm inline-block border border-amber-200">
                      بانتظار تعيين فني
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-sm">
            <CardHeader className="pb-3 border-b">
              <CardTitle>الصور والمرفقات</CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="border-2 border-dashed border-muted-foreground/20 rounded-xl p-8 text-center hover:bg-muted/10 transition-colors cursor-pointer">
                <ImageIcon className="h-10 w-10 text-muted-foreground/40 mx-auto mb-3" />
                <p className="font-medium text-muted-foreground">لا توجد صور مرفقة</p>
                <p className="text-xs text-muted-foreground mt-1">انقر لإضافة صور للمشكلة أو تقرير الإنجاز</p>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="border-none shadow-sm bg-card h-fit">
            <CardHeader className="pb-3 border-b">
              <CardTitle>معلومات إضافية</CardTitle>
            </CardHeader>
            <CardContent className="pt-4 space-y-4">
              <div className="flex justify-between items-center text-sm">
                <span className="text-muted-foreground">مستوى الأولوية:</span>
                <span className={`font-bold ${priorityColor}`}>{request.priority}</span>
              </div>
              
              <div className="pt-4 border-t border-border/50">
                <h4 className="text-sm font-semibold text-muted-foreground mb-3">بيانات المبلّغ</h4>
                {tenant ? (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm">
                      <User className="h-4 w-4 text-primary" />
                      <Link href={`/tenants/${tenant.id}`} className="font-medium hover:underline">{tenant.name}</Link>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Phone className="h-4 w-4" />
                      <span dir="ltr">{tenant.phone}</span>
                    </div>
                  </div>
                ) : (
                  <div className="text-sm text-muted-foreground">تم الإبلاغ من قبل الإدارة (صيانة دورية/مرافق)</div>
                )}
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-sm bg-card h-fit">
            <CardHeader className="pb-3 border-b">
              <CardTitle>سجل التحديثات</CardTitle>
            </CardHeader>
            <CardContent className="pt-4">
              <div className="relative border-r-2 border-muted pr-4 mr-2 space-y-5">
                
                <div className="relative">
                  <div className="absolute -right-[21px] top-1 h-3 w-3 rounded-full bg-muted border-2 border-background"></div>
                  <div>
                    <p className="font-medium text-sm">إنشاء الطلب</p>
                    <p className="text-xs text-muted-foreground mt-1">{request.date}</p>
                  </div>
                </div>

                {request.status !== 'مفتوح' && request.status !== 'ملغي' && (
                  <div className="relative">
                    <div className="absolute -right-[21px] top-1 h-3 w-3 rounded-full bg-blue-500 border-2 border-background"></div>
                    <div>
                      <p className="font-medium text-sm">بدء التنفيذ وتعيين فني</p>
                      <p className="text-xs text-muted-foreground mt-1">بواسطة مدير النظام</p>
                    </div>
                  </div>
                )}

                {request.status === 'مكتمل' && (
                  <div className="relative">
                    <div className="absolute -right-[21px] top-1 h-3 w-3 rounded-full bg-emerald-500 border-2 border-background"></div>
                    <div>
                      <p className="font-medium text-sm">إغلاق الطلب (مكتمل)</p>
                      <p className="text-xs text-muted-foreground mt-1">تم حل المشكلة</p>
                    </div>
                  </div>
                )}
                
                {request.status === 'ملغي' && (
                  <div className="relative">
                    <div className="absolute -right-[21px] top-1 h-3 w-3 rounded-full bg-destructive border-2 border-background"></div>
                    <div>
                      <p className="font-medium text-sm text-destructive">تم إلغاء الطلب</p>
                    </div>
                  </div>
                )}

              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}