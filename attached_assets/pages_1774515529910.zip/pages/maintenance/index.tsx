import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Search, Filter, MoreHorizontal, Eye, Edit, Trash, FileText, CheckCircle2, Clock, Gavel } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useAppStore } from "@/store";
import { Maintenance } from "@/types";
import { useToast } from "@/hooks/use-toast";

export default function MaintenanceList() {
  const { maintenance, properties, units, addMaintenance, updateMaintenance, cancelMaintenance } = useAppStore();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const [isAddOpen, setIsAddOpen] = useState(false);
  const [formData, setFormData] = useState<Partial<Maintenance>>({ status: 'مفتوح', priority: 'متوسط' });

  const getLocationDetails = (propertyId: string, unitId: string) => {
    const property = properties.find(p => p.id === propertyId);
    const unit = units.find(u => u.id === unitId);
    return {
      propertyName: property?.name || 'غير معروف',
      unitName: unit?.number || 'غير معروف'
    };
  };

  const handleSave = () => {
    if (!formData.propertyId || !formData.title || !formData.description) {
      toast({ title: "خطأ", description: "الرجاء تعبئة الحقول الأساسية", variant: "destructive" });
      return;
    }
    
    // Set current date if not provided
    const newMaintenance = {
      ...formData,
      date: formData.date || new Date().toISOString().split('T')[0],
      technician: formData.technician || 'لم يحدد',
      unitId: formData.unitId || '-' // Some maintenance might be for common areas
    };
    
    addMaintenance(newMaintenance as Omit<Maintenance, 'id'>);
    toast({ title: "نجاح", description: "تم تسجيل طلب الصيانة بنجاح" });
    setIsAddOpen(false);
    setFormData({ status: 'مفتوح', priority: 'متوسط' });
  };

  const handleCancel = (id: string) => {
    if(confirm("هل أنت متأكد من إلغاء طلب الصيانة؟")) {
      cancelMaintenance(id);
      toast({ title: "تم الإلغاء", description: "تم إلغاء طلب الصيانة بنجاح" });
    }
  };

  const stats = {
    total: maintenance.filter(m => m.status !== 'ملغي').length,
    open: maintenance.filter(m => m.status === 'مفتوح' || m.status === 'قيد التنفيذ').length,
    urgent: maintenance.filter(m => m.priority === 'عاجل' && m.status !== 'مكتمل' && m.status !== 'ملغي').length,
    completed: maintenance.filter(m => m.status === 'مكتمل').length,
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground">طلبات الصيانة</h1>
          <p className="text-muted-foreground mt-1">إدارة ومتابعة طلبات الصيانة الدورية والطارئة</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="bg-background">
            <FileText className="mr-2 h-4 w-4" />
            تصدير تقرير
          </Button>
          
          <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
            <DialogTrigger asChild>
              <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
                <Plus className="mr-2 h-4 w-4" />
                إضافة طلب صيانة
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>تسجيل طلب صيانة جديد</DialogTitle>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="title">عنوان الطلب</Label>
                  <Input id="title" value={formData.title || ''} onChange={e => setFormData({...formData, title: e.target.value})} placeholder="مثال: عطل في التكييف" />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="propertyId">العقار</Label>
                    <Select value={formData.propertyId} onValueChange={(val) => setFormData({...formData, propertyId: val, unitId: undefined})}>
                      <SelectTrigger>
                        <SelectValue placeholder="اختر العقار" />
                      </SelectTrigger>
                      <SelectContent>
                        {properties.map(property => (
                          <SelectItem key={property.id} value={property.id}>{property.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="unitId">الوحدة (اختياري)</Label>
                    <Select 
                      value={formData.unitId} 
                      onValueChange={(val) => setFormData({...formData, unitId: val})}
                      disabled={!formData.propertyId}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="اختر الوحدة" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="-">المرافق المشتركة</SelectItem>
                        {units.filter(u => u.propertyId === formData.propertyId).map(unit => (
                          <SelectItem key={unit.id} value={unit.id}>{unit.number}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="description">تفاصيل المشكلة</Label>
                  <Textarea 
                    id="description" 
                    value={formData.description || ''} 
                    onChange={e => setFormData({...formData, description: e.target.value})}
                    placeholder="وصف مفصل للمشكلة والاحتياج..."
                    rows={3}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="priority">الأولوية</Label>
                    <Select value={formData.priority} onValueChange={(val: any) => setFormData({...formData, priority: val})}>
                      <SelectTrigger>
                        <SelectValue placeholder="اختر الأولوية" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="منخفض">منخفض</SelectItem>
                        <SelectItem value="متوسط">متوسط</SelectItem>
                        <SelectItem value="عاجل">عاجل</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="technician">الفني / المقاول (اختياري)</Label>
                    <Input id="technician" value={formData.technician || ''} onChange={e => setFormData({...formData, technician: e.target.value})} placeholder="اسم الفني أو الشركة" />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddOpen(false)}>إلغاء</Button>
                <Button onClick={handleSave}>تسجيل الطلب</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="border-none shadow-sm bg-card">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">إجمالي الطلبات</p>
              <p className="text-2xl font-bold">{stats.total}</p>
            </div>
            <div className="p-2 bg-primary/10 rounded-lg">
              <Gavel className="h-5 w-5 text-primary" />
            </div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm bg-card">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">طلبات نشطة</p>
              <p className="text-2xl font-bold text-amber-500">{stats.open}</p>
            </div>
            <div className="p-2 bg-amber-500/10 rounded-lg">
              <Clock className="h-5 w-5 text-amber-500" />
            </div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm bg-card">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">طلبات عاجلة</p>
              <p className="text-2xl font-bold text-destructive">{stats.urgent}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm bg-card">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">طلبات مكتملة</p>
              <p className="text-2xl font-bold text-emerald-500">{stats.completed}</p>
            </div>
            <div className="p-2 bg-emerald-500/10 rounded-lg">
              <CheckCircle2 className="h-5 w-5 text-emerald-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-none shadow-sm">
        <CardHeader className="pb-3 border-b">
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
            <div className="relative w-full sm:w-96">
              <Search className="absolute right-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="البحث برقم الطلب، الوصف، أو الوحدة..."
                className="pr-9 bg-muted/50 border-none"
              />
            </div>
            <div className="flex gap-2 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0">
              <Button variant="secondary" size="sm" className="whitespace-nowrap">الكل</Button>
              <Button variant="ghost" size="sm" className="whitespace-nowrap text-muted-foreground">مفتوح</Button>
              <Button variant="ghost" size="sm" className="whitespace-nowrap text-muted-foreground">قيد التنفيذ</Button>
              <Button variant="ghost" size="sm" className="whitespace-nowrap text-muted-foreground">مكتمل</Button>
              <Button variant="outline" size="icon" className="ml-auto sm:ml-2">
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-right">
              <thead className="bg-muted/30">
                <tr className="border-b">
                  <th className="px-4 py-3 font-medium text-muted-foreground">رقم الطلب</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">الوصف</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">العقار / الوحدة</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">الأولوية</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">تاريخ الطلب</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">الفني / المقاول</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">الحالة</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground w-[80px]">إجراءات</th>
                </tr>
              </thead>
              <tbody>
                {maintenance.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="text-center py-8 text-muted-foreground">لا توجد طلبات صيانة</td>
                  </tr>
                ) : maintenance.map((request) => {
                  let statusColor = "bg-muted text-muted-foreground";
                  if (request.status === "مكتمل") statusColor = "bg-emerald-500/10 text-emerald-500";
                  else if (request.status === "قيد التنفيذ") statusColor = "bg-blue-500/10 text-blue-500";
                  else if (request.status === "مفتوح") statusColor = "bg-amber-500/10 text-amber-500";
                  else if (request.status === "ملغي") statusColor = "bg-muted text-muted-foreground line-through";
                  
                  let priorityColor = "bg-muted text-muted-foreground";
                  if (request.priority === "عاجل") priorityColor = "bg-destructive/10 text-destructive";
                  else if (request.priority === "متوسط") priorityColor = "bg-amber-500/10 text-amber-500";
                  else if (request.priority === "منخفض") priorityColor = "bg-emerald-500/10 text-emerald-500";

                  const loc = getLocationDetails(request.propertyId, request.unitId);

                  return (
                    <tr 
                      key={request.id} 
                      className={`border-b last:border-0 hover:bg-muted/20 transition-colors cursor-pointer ${request.status === 'ملغي' ? 'opacity-50' : ''}`}
                      onClick={() => setLocation(`/maintenance/${request.id}`)}
                    >
                      <td className="px-4 py-3 font-medium text-primary">{request.id}</td>
                      <td className="px-4 py-3 font-medium">{request.title}</td>
                      <td className="px-4 py-3">
                        <div className="flex flex-col">
                          <span>{request.unitId === '-' ? 'مرافق مشتركة' : loc.unitName}</span>
                          <span className="text-xs text-muted-foreground">{loc.propertyName}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${priorityColor}`}>
                          {request.priority}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-muted-foreground">{request.date}</td>
                      <td className="px-4 py-3 text-muted-foreground">{request.technician}</td>
                      <td className="px-4 py-3">
                        <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${statusColor}`}>
                          {request.status}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <span className="sr-only">فتح القائمة</span>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem className="cursor-pointer">
                              <Eye className="mr-2 h-4 w-4" />
                              <span>عرض التفاصيل</span>
                            </DropdownMenuItem>
                            {request.status !== 'ملغي' && (
                              <DropdownMenuItem className="cursor-pointer">
                                <Edit className="mr-2 h-4 w-4" />
                                <span>تحديث الحالة</span>
                              </DropdownMenuItem>
                            )}
                            {request.status !== 'مكتمل' && request.status !== 'ملغي' && (
                              <DropdownMenuItem className="cursor-pointer text-destructive" onClick={() => handleCancel(request.id)}>
                                <Trash className="mr-2 h-4 w-4" />
                                <span>إلغاء الطلب</span>
                              </DropdownMenuItem>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}