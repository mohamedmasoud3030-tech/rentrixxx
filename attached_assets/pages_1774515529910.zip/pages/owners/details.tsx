import { useParams, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Building2, FileText, Phone, Mail, User, MapPin } from "lucide-react";
import { useAppStore } from "@/store";

export default function OwnerDetails() {
  const { id } = useParams();
  const { owners, properties, contracts, units } = useAppStore();
  
  const owner = owners.find(o => o.id === id);
  
  if (!owner) {
    return (
      <div className="flex flex-col items-center justify-center h-full space-y-4">
        <h2 className="text-2xl font-bold">المالك غير موجود</h2>
        <Link href="/owners"><Button variant="outline">العودة لقائمة الملاك</Button></Link>
      </div>
    );
  }

  const ownerProperties = properties.filter(p => p.ownerId === id);
  const propertyIds = ownerProperties.map(p => p.id);
  const ownerUnits = units.filter(u => propertyIds.includes(u.propertyId));
  
  // Find contracts for these units
  const unitIds = ownerUnits.map(u => u.id);
  const ownerContracts = contracts.filter(c => unitIds.includes(c.unitId));
  
  const activeContracts = ownerContracts.filter(c => c.status === 'ساري' || c.status === 'قارب على الانتهاء').length;
  const totalPropertyValue = ownerUnits.reduce((sum, u) => sum + u.estimatedPrice, 0);

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center gap-4">
        <Link href="/owners">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <ArrowRight className="h-4 w-4" />
          </Button>
        </Link>
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground">تفاصيل المالك: {owner.name}</h1>
          <p className="text-muted-foreground mt-1">رقم المالك: {owner.id}</p>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <Card className="md:col-span-1 border-none shadow-sm">
          <CardHeader>
            <CardTitle>البيانات الأساسية</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-3 text-sm">
              <User className="h-4 w-4 text-muted-foreground" />
              <span className="font-medium w-24">النوع:</span>
              <Badge variant="outline">{owner.type}</Badge>
            </div>
            <div className="flex items-center gap-3 text-sm">
              <FileText className="h-4 w-4 text-muted-foreground" />
              <span className="font-medium w-24">الهوية/السجل:</span>
              <span>{owner.nationalId}</span>
            </div>
            <div className="flex items-center gap-3 text-sm">
              <Phone className="h-4 w-4 text-muted-foreground" />
              <span className="font-medium w-24">الجوال:</span>
              <span dir="ltr">{owner.phone}</span>
            </div>
            {owner.email && (
              <div className="flex items-center gap-3 text-sm">
                <Mail className="h-4 w-4 text-muted-foreground" />
                <span className="font-medium w-24">البريد:</span>
                <span className="truncate">{owner.email}</span>
              </div>
            )}
            
            <div className="pt-4 border-t mt-4 space-y-3">
              <div className="flex justify-between items-center text-sm">
                <span className="text-muted-foreground">إجمالي العقارات:</span>
                <span className="font-bold">{ownerProperties.length}</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-muted-foreground">إجمالي الوحدات:</span>
                <span className="font-bold">{ownerUnits.length}</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-muted-foreground">عقود نشطة:</span>
                <span className="font-bold text-emerald-600">{activeContracts}</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-muted-foreground">القيمة التقديرية:</span>
                <span className="font-bold">{totalPropertyValue.toLocaleString()} ﷼</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="md:col-span-2 border-none shadow-sm">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>العقارات المملوكة</CardTitle>
              <Link href="/properties">
                <Button variant="outline" size="sm">إضافة عقار</Button>
              </Link>
            </div>
          </CardHeader>
          <CardContent>
            {ownerProperties.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground flex flex-col items-center">
                <Building2 className="h-12 w-12 text-muted-foreground/30 mb-3" />
                <p>لا يوجد عقارات مسجلة لهذا المالك</p>
              </div>
            ) : (
              <div className="space-y-4">
                {ownerProperties.map(property => {
                  const propUnits = units.filter(u => u.propertyId === property.id);
                  const occupied = propUnits.filter(u => u.status === 'مؤجرة').length;
                  
                  return (
                    <div key={property.id} className="flex flex-col sm:flex-row justify-between items-start sm:items-center p-4 rounded-lg border bg-card hover:bg-muted/10 transition-colors gap-4">
                      <div className="flex items-start gap-3">
                        <div className="p-2 bg-primary/10 rounded-md mt-1">
                          <Building2 className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <h4 className="font-bold text-base">
                            <Link href={`/properties/${property.id}`} className="hover:underline text-foreground">
                              {property.name}
                            </Link>
                          </h4>
                          <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                            <MapPin className="h-3 w-3" />
                            <span>{property.location}</span>
                            <span>•</span>
                            <span>{property.type}</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-6 w-full sm:w-auto">
                        <div className="text-center">
                          <p className="text-xs text-muted-foreground mb-1">الوحدات</p>
                          <p className="font-semibold text-sm">{propUnits.length}</p>
                        </div>
                        <div className="text-center">
                          <p className="text-xs text-muted-foreground mb-1">مؤجرة</p>
                          <p className="font-semibold text-sm text-emerald-600">{occupied}</p>
                        </div>
                        <Link href={`/properties/${property.id}`}>
                          <Button variant="ghost" size="sm">تفاصيل</Button>
                        </Link>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}