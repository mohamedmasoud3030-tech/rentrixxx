import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Plus, Search, Filter, MoreHorizontal, Eye, Edit, Trash } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAppStore } from "@/store";
import { Owner } from "@/types";
import { useToast } from "@/hooks/use-toast";

export default function OwnersList() {
  const { owners, properties, contracts, addOwner, updateOwner, deleteOwner } = useAppStore();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [formData, setFormData] = useState<Partial<Owner>>({ type: 'فرد' });

  const getOwnerStats = (ownerId: string) => {
    const ownerProperties = properties.filter(p => p.ownerId === ownerId);
    const propertiesCount = ownerProperties.length;
    const activeContracts = contracts.filter(c => c.status === 'ساري').length; // Simplified
    return { propertiesCount, activeContracts };
  };

  const handleSave = () => {
    if (!formData.name || !formData.phone || !formData.nationalId) {
      toast({ title: "خطأ", description: "الرجاء تعبئة الحقول الأساسية", variant: "destructive" });
      return;
    }
    
    addOwner(formData as Omit<Owner, 'id'>);
    toast({ title: "نجاح", description: "تمت إضافة المالك بنجاح" });
    setIsAddOpen(false);
    setFormData({ type: 'فرد' });
  };

  const handleDelete = (id: string) => {
    if(confirm("هل أنت متأكد من حذف هذا المالك؟")) {
      deleteOwner(id);
      toast({ title: "تم الحذف", description: "تم حذف المالك بنجاح" });
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground">الملاك</h1>
          <p className="text-muted-foreground mt-1">إدارة بيانات الملاك ومحافظهم العقارية</p>
        </div>
        
        <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
          <DialogTrigger asChild>
            <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
              <Plus className="mr-2 h-4 w-4" />
              إضافة مالك جديد
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>إضافة مالك جديد</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="name">اسم المالك</Label>
                <Input id="name" value={formData.name || ''} onChange={e => setFormData({...formData, name: e.target.value})} placeholder="الاسم الكامل أو اسم الشركة" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="type">النوع</Label>
                  <Select value={formData.type} onValueChange={(val: any) => setFormData({...formData, type: val})}>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر النوع" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="فرد">فرد</SelectItem>
                      <SelectItem value="شركة">شركة</SelectItem>
                      <SelectItem value="مؤسسة">مؤسسة</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="nationalId">الهوية / السجل التجاري</Label>
                  <Input id="nationalId" value={formData.nationalId || ''} onChange={e => setFormData({...formData, nationalId: e.target.value})} placeholder="رقم الهوية أو السجل" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="phone">رقم الجوال</Label>
                  <Input id="phone" value={formData.phone || ''} onChange={e => setFormData({...formData, phone: e.target.value})} placeholder="05xxxxxxxx" dir="ltr" className="text-right" />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="email">البريد الإلكتروني</Label>
                  <Input id="email" type="email" value={formData.email || ''} onChange={e => setFormData({...formData, email: e.target.value})} placeholder="example@domain.com" dir="ltr" className="text-right" />
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAddOpen(false)}>إلغاء</Button>
              <Button onClick={handleSave}>حفظ البيانات</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="border-none shadow-sm">
        <CardHeader className="pb-3 border-b">
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
            <div className="relative w-full sm:w-96">
              <Search className="absolute right-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="البحث باسم المالك، الهوية، أو الجوال..."
                className="pr-9 bg-muted/50 border-none"
              />
            </div>
            <Button variant="outline" className="w-full sm:w-auto">
              <Filter className="mr-2 h-4 w-4" />
              تصفية
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-right">
              <thead className="bg-muted/30">
                <tr className="border-b">
                  <th className="px-4 py-3 font-medium text-muted-foreground">رقم المالك</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">الاسم</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">النوع</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">رقم التواصل</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">العقارات</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground w-[80px]">إجراءات</th>
                </tr>
              </thead>
              <tbody>
                {owners.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="text-center py-8 text-muted-foreground">لا يوجد ملاك مسجلين</td>
                  </tr>
                ) : owners.map((owner) => {
                  const stats = getOwnerStats(owner.id);
                  return (
                  <tr 
                    key={owner.id} 
                    className="border-b last:border-0 hover:bg-muted/20 transition-colors cursor-pointer"
                    onClick={() => setLocation(`/owners/${owner.id}`)}
                  >
                    <td className="px-4 py-3 font-medium text-primary">{owner.id}</td>
                    <td className="px-4 py-3 font-medium">{owner.name}</td>
                    <td className="px-4 py-3">
                      <span className="px-2.5 py-1 rounded-full text-xs font-medium bg-secondary text-secondary-foreground">
                        {owner.type}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground" dir="ltr">{owner.phone}</td>
                    <td className="px-4 py-3 font-medium">{stats.propertiesCount}</td>
                    <td className="px-4 py-3">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0">
                            <span className="sr-only">فتح القائمة</span>
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem className="cursor-pointer">
                            <Eye className="mr-2 h-4 w-4" />
                            <span>عرض التفاصيل</span>
                          </DropdownMenuItem>
                          <DropdownMenuItem className="cursor-pointer">
                            <Edit className="mr-2 h-4 w-4" />
                            <span>تعديل البيانات</span>
                          </DropdownMenuItem>
                          <DropdownMenuItem className="cursor-pointer text-destructive" onClick={() => handleDelete(owner.id)}>
                            <Trash className="mr-2 h-4 w-4" />
                            <span>حذف</span>
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </td>
                  </tr>
                )})}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}