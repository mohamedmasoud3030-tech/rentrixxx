import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Search, Download, Users, Building2, ShieldAlert, Activity } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { useAppStore } from "@/store";

export default function UsersAndSettings() {
  const { auditLogs } = useAppStore();

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div>
        <h1 className="text-3xl font-display font-bold text-foreground">الإعدادات والمستخدمين</h1>
        <p className="text-muted-foreground mt-1">إدارة مستخدمي النظام والصلاحيات والإعدادات العامة</p>
      </div>

      <Tabs defaultValue="activity" className="w-full">
        <TabsList className="w-full justify-start border-b rounded-none h-auto p-0 bg-transparent mb-6 overflow-x-auto">
          <TabsTrigger value="activity" className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-6 py-3">
            <Activity className="h-4 w-4 ml-2" />
            سجل النشاطات
          </TabsTrigger>
          <TabsTrigger value="users" className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-6 py-3">
            <Users className="h-4 w-4 ml-2" />
            المستخدمين
          </TabsTrigger>
          <TabsTrigger value="roles" className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-6 py-3">
            <ShieldAlert className="h-4 w-4 ml-2" />
            الصلاحيات
          </TabsTrigger>
          <TabsTrigger value="settings" className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-6 py-3">
            <Building2 className="h-4 w-4 ml-2" />
            إعدادات الشركة
          </TabsTrigger>
        </TabsList>

        <TabsContent value="activity" className="space-y-4">
          <Card className="border-none shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <div>
                <CardTitle>سجل النشاطات (Audit Log)</CardTitle>
                <CardDescription>تتبع كافة العمليات التي تمت على النظام</CardDescription>
              </div>
              <Button variant="outline" size="sm">
                <Download className="mr-2 h-4 w-4" />
                تصدير السجل
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 max-h-[600px] overflow-y-auto pr-2">
                {auditLogs.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">لا توجد نشاطات مسجلة بعد</p>
                ) : (
                  auditLogs.map((log) => (
                    <div key={log.id} className="flex items-start gap-4 p-3 rounded-lg bg-muted/20 border border-border/50 hover:bg-muted/40 transition-colors">
                      <div className="mt-1.5 h-2 w-2 rounded-full bg-primary shrink-0" />
                      <div className="flex-1">
                        <p className="text-sm font-medium">
                          قام <span className="text-primary">{log.user}</span> بـ <span className="font-bold">{log.action}</span> 
                          {log.target && log.target !== "النظام" && (
                            <span className="text-muted-foreground mr-1">({log.target})</span>
                          )}
                        </p>
                        <p className="text-xs text-muted-foreground mt-1" dir="ltr">{log.time}</p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="users" className="space-y-4">
          <div className="flex justify-between items-center">
            <div className="relative w-full max-w-sm">
              <Search className="absolute right-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input placeholder="البحث عن مستخدم..." className="pr-9" />
            </div>
            <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
              <Plus className="mr-2 h-4 w-4" />
              إضافة مستخدم
            </Button>
          </div>
          
          <Card className="border-none shadow-sm">
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full text-sm text-right">
                  <thead className="bg-muted/30 border-b">
                    <tr>
                      <th className="px-4 py-3 font-medium text-muted-foreground">الاسم</th>
                      <th className="px-4 py-3 font-medium text-muted-foreground">البريد الإلكتروني</th>
                      <th className="px-4 py-3 font-medium text-muted-foreground">الدور</th>
                      <th className="px-4 py-3 font-medium text-muted-foreground">تاريخ الإضافة</th>
                      <th className="px-4 py-3 font-medium text-muted-foreground">الحالة</th>
                      <th className="px-4 py-3 font-medium text-muted-foreground w-[100px]">إجراءات</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      { name: "أحمد محمد", email: "ahmed@rentrix.com", role: "مدير نظام", date: "2023-01-15", status: true },
                      { name: "خالد السالم", email: "khaled@rentrix.com", role: "محاسب", date: "2023-03-22", status: true },
                      { name: "فهد الدوسري", email: "fahad@rentrix.com", role: "مدير أملاك", date: "2023-05-10", status: true },
                      { name: "سعد القحطاني", email: "saad@rentrix.com", role: "مدخل بيانات", date: "2023-11-05", status: false },
                    ].map((user, i) => (
                      <tr key={i} className="border-b last:border-0 hover:bg-muted/20 transition-colors">
                        <td className="px-4 py-3 font-medium">
                          <div className="flex items-center gap-2">
                            <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">
                              {user.name.charAt(0)}
                            </div>
                            {user.name}
                          </div>
                        </td>
                        <td className="px-4 py-3 text-muted-foreground">{user.email}</td>
                        <td className="px-4 py-3">
                          <Badge variant="outline" className="bg-background">{user.role}</Badge>
                        </td>
                        <td className="px-4 py-3 text-muted-foreground">{user.date}</td>
                        <td className="px-4 py-3">
                          <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${user.status ? 'bg-emerald-500/10 text-emerald-500' : 'bg-muted text-muted-foreground'}`}>
                            {user.status ? 'نشط' : 'غير نشط'}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <Button variant="ghost" size="sm">تعديل</Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="roles" className="space-y-4">
          <div className="flex justify-between items-center">
            <p className="text-muted-foreground">إدارة الأدوار وصلاحيات الوصول للنظام</p>
            <Button variant="outline">إضافة دور جديد</Button>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              { title: "مدير نظام", desc: "صلاحيات كاملة على كافة أجزاء النظام", count: 1 },
              { title: "مدير أملاك", desc: "صلاحيات على العقارات والوحدات والعقود فقط", count: 3 },
              { title: "محاسب", desc: "صلاحيات على الاستحقاقات والتحصيلات والمصروفات", count: 2 },
              { title: "مدخل بيانات", desc: "صلاحيات إضافة فقط دون التعديل أو الحذف", count: 4 },
            ].map((role, i) => (
              <Card key={i} className="border-none shadow-sm bg-card hover:shadow-md transition-shadow">
                <CardHeader className="pb-2">
                  <CardTitle className="flex items-center justify-between">
                    <span>{role.title}</span>
                    <Badge variant="secondary">{role.count} مستخدم</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">{role.desc}</p>
                  <Button variant="ghost" size="sm" className="w-full">تعديل الصلاحيات</Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="settings" className="space-y-4">
          <div className="grid md:grid-cols-2 gap-6">
            <Card className="border-none shadow-sm">
              <CardHeader>
                <CardTitle>بيانات الشركة</CardTitle>
                <CardDescription>هذه البيانات ستظهر في الفواتير والعقود المطبوعة</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">اسم الشركة / المكتب</label>
                  <Input defaultValue="شركة رينتريكس لإدارة الأملاك" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">رقم السجل التجاري</label>
                    <Input defaultValue="1010123456" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">الرقم الضريبي</label>
                    <Input defaultValue="300123456700003" />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">العنوان الوطني</label>
                  <Input defaultValue="الرياض، حي العليا، طريق الملك فهد" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">الهاتف</label>
                  <Input defaultValue="920012345" />
                </div>
                <Button className="w-full mt-4 bg-primary text-primary-foreground">حفظ التغييرات</Button>
              </CardContent>
            </Card>

            <Card className="border-none shadow-sm">
              <CardHeader>
                <CardTitle>إعدادات النظام</CardTitle>
                <CardDescription>تخصيص سلوك النظام والإشعارات</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <p className="text-sm font-medium">تنبيهات العقود</p>
                    <p className="text-xs text-muted-foreground">إرسال تنبيه قبل انتهاء العقد بـ 30 يوم</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <p className="text-sm font-medium">رسائل نصية للمستأجرين</p>
                    <p className="text-xs text-muted-foreground">إرسال رسالة SMS عند صدور فاتورة جديدة</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <p className="text-sm font-medium">التسلسل التلقائي</p>
                    <p className="text-xs text-muted-foreground">توليد أرقام العقود والفواتير تلقائياً</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <p className="text-sm font-medium">منع الحذف</p>
                    <p className="text-xs text-muted-foreground">منع حذف السجلات المالية والاكتفاء بإلغائها</p>
                  </div>
                  <Switch defaultChecked disabled />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}