import { useParams, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, MapPin, User, Home, Key, CheckCircle2, XCircle, Gavel } from "lucide-react";
import { useAppStore } from "@/store";

export default function PropertyDetails() {
  const { id } = useParams();
  const { properties, owners, units, contracts } = useAppStore();
  
  const property = properties.find(p => p.id === id);
  
  if (!property) {
    return (
      <div className="flex flex-col items-center justify-center h-full space-y-4">
        <h2 className="text-2xl font-bold">العقار غير موجود</h2>
        <Link href="/properties"><Button variant="outline">العودة لقائمة العقارات</Button></Link>
      </div>
    );
  }

  const owner = owners.find(o => o.id === property.ownerId);
  const propertyUnits = units.filter(u => u.propertyId === id);
  
  const occupiedUnits = propertyUnits.filter(u => u.status === 'مؤجرة').length;
  const vacantUnits = propertyUnits.filter(u => u.status === 'شاغرة').length;
  const maintenanceUnits = propertyUnits.filter(u => u.status === 'صيانة').length;
  
  const occupancyRate = propertyUnits.length > 0 ? Math.round((occupiedUnits / propertyUnits.length) * 100) : 0;
  const totalValue = propertyUnits.reduce((sum, u) => sum + u.estimatedPrice, 0);

  // Active contracts for this property
  const unitIds = propertyUnits.map(u => u.id);
  const activeContracts = contracts.filter(c => unitIds.includes(c.unitId) && (c.status === 'ساري' || c.status === 'قارب على الانتهاء'));

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-4">
          <Link href="/properties">
            <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
              <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-display font-bold text-foreground">{property.name}</h1>
            <div className="flex items-center gap-2 mt-1 text-muted-foreground text-sm">
              <span>رقم العقار: {property.id}</span>
              <span>•</span>
              <Badge variant="secondary" className="font-normal">{property.type}</Badge>
            </div>
          </div>
        </div>
        <div className="flex gap-2">
          <Link href={`/units?property=${property.id}`}>
            <Button variant="outline">عرض كل الوحدات</Button>
          </Link>
          <Button className="bg-primary text-primary-foreground">إضافة وحدة</Button>
        </div>
      </div>

      <div className="grid md:grid-cols-4 gap-6">
        <Card className="md:col-span-1 border-none shadow-sm h-fit">
          <CardHeader>
            <CardTitle>تفاصيل العقار</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-start gap-3 text-sm">
              <MapPin className="h-4 w-4 text-muted-foreground mt-0.5" />
              <div>
                <span className="font-medium block mb-1">الموقع:</span>
                <span className="text-muted-foreground leading-relaxed">{property.location}</span>
              </div>
            </div>
            
            <div className="flex items-start gap-3 text-sm pt-3 border-t">
              <User className="h-4 w-4 text-muted-foreground mt-0.5" />
              <div>
                <span className="font-medium block mb-1">المالك:</span>
                {owner ? (
                  <Link href={`/owners/${owner.id}`} className="text-primary hover:underline">
                    {owner.name}
                  </Link>
                ) : (
                  <span className="text-muted-foreground">غير محدد</span>
                )}
              </div>
            </div>

            <div className="pt-4 border-t mt-4 space-y-3">
              <div className="flex justify-between items-center text-sm">
                <span className="text-muted-foreground">إجمالي الوحدات:</span>
                <span className="font-bold">{propertyUnits.length}</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-muted-foreground">الوحدات المؤجرة:</span>
                <span className="font-bold text-emerald-600">{occupiedUnits}</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-muted-foreground">الوحدات الشاغرة:</span>
                <span className="font-bold text-blue-600">{vacantUnits}</span>
              </div>
              <div className="flex justify-between items-center text-sm pt-2 border-t">
                <span className="text-muted-foreground">القيمة التقديرية الكلية:</span>
                <span className="font-bold">{totalValue.toLocaleString()} ﷼</span>
              </div>
            </div>

            <div className="pt-4">
              <div className="flex justify-between items-center text-sm mb-2">
                <span className="font-medium">نسبة الإشغال</span>
                <span className="font-bold">{occupancyRate}%</span>
              </div>
              <div className="h-2 w-full bg-muted rounded-full overflow-hidden">
                <div 
                  className={`h-full ${occupancyRate < 50 ? 'bg-destructive' : occupancyRate < 80 ? 'bg-amber-500' : 'bg-emerald-500'}`} 
                  style={{ width: `${occupancyRate}%` }}
                />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="md:col-span-3 border-none shadow-sm">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>الوحدات ({propertyUnits.length})</CardTitle>
              <div className="flex gap-2 text-sm">
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-emerald-500"></span> مؤجرة</span>
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-blue-500"></span> شاغرة</span>
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-amber-500"></span> صيانة</span>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {propertyUnits.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground flex flex-col items-center">
                <Home className="h-12 w-12 text-muted-foreground/30 mb-3" />
                <p>لا يوجد وحدات مسجلة في هذا العقار</p>
                <Button variant="outline" className="mt-4">إضافة الوحدة الأولى</Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {propertyUnits.map(unit => {
                  const contract = activeContracts.find(c => c.unitId === unit.id);
                  let statusColor = "bg-muted";
                  let Icon = Key;
                  
                  if (unit.status === 'مؤجرة') {
                    statusColor = "border-emerald-200 bg-emerald-50/50";
                    Icon = CheckCircle2;
                  } else if (unit.status === 'شاغرة') {
                    statusColor = "border-blue-200 bg-blue-50/50";
                    Icon = Home;
                  } else if (unit.status === 'صيانة') {
                    statusColor = "border-amber-200 bg-amber-50/50";
                    Icon = Gavel;
                  }

                  return (
                    <div key={unit.id} className={`border rounded-lg p-4 flex flex-col justify-between ${statusColor} hover:shadow-md transition-shadow`}>
                      <div>
                        <div className="flex justify-between items-start mb-2">
                          <h4 className="font-bold text-lg">
                            <Link href={`/units/${unit.id}`} className="hover:underline">
                              {unit.number}
                            </Link>
                          </h4>
                          <Icon className={`h-5 w-5 ${unit.status === 'مؤجرة' ? 'text-emerald-500' : unit.status === 'شاغرة' ? 'text-blue-500' : 'text-amber-500'}`} />
                        </div>
                        <div className="text-sm space-y-1 mb-4 text-muted-foreground">
                          <p>{unit.type} • {unit.rooms} غرف • {unit.floor}</p>
                          <p className="font-medium text-foreground">{unit.estimatedPrice.toLocaleString()} ﷼ <span className="text-xs font-normal text-muted-foreground">/ سنوياً</span></p>
                        </div>
                      </div>
                      
                      <div className="pt-3 border-t border-border/50">
                        {contract ? (
                          <div className="text-xs">
                            <span className="text-muted-foreground">مؤجرة لـ: </span>
                            <span className="font-medium truncate block mt-0.5">{contract.id}</span>
                          </div>
                        ) : (
                          <div className="text-xs text-muted-foreground flex items-center justify-between">
                            <span>جاهزة للتأجير</span>
                            <Link href={`/contracts?unit=${unit.id}`}>
                              <Button variant="link" className="h-auto p-0 text-xs text-primary">إنشاء عقد</Button>
                            </Link>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}