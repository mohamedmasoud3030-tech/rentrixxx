import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Plus, Search, Filter, MoreHorizontal, Eye, Edit, Trash, MapPin } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useAppStore } from "@/store";
import { Property } from "@/types";
import { useToast } from "@/hooks/use-toast";

export default function PropertiesList() {
  const { properties, owners, units, addProperty, updateProperty, deleteProperty } = useAppStore();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const [isAddOpen, setIsAddOpen] = useState(false);
  const [formData, setFormData] = useState<Partial<Property>>({ type: 'سكني', unitsCount: 1 });

  const getPropertyStats = (propertyId: string) => {
    const propertyUnits = units.filter(u => u.propertyId === propertyId);
    const occupiedUnits = propertyUnits.filter(u => u.status === 'مؤجرة').length;
    return {
      unitsCount: propertyUnits.length,
      occupiedUnits
    };
  };

  const getOwnerName = (ownerId: string) => {
    return owners.find(o => o.id === ownerId)?.name || 'غير معروف';
  };

  const handleSave = () => {
    if (!formData.name || !formData.ownerId || !formData.location) {
      toast({ title: "خطأ", description: "الرجاء تعبئة الحقول الأساسية (الاسم، المالك، الموقع)", variant: "destructive" });
      return;
    }
    
    addProperty(formData as Omit<Property, 'id'>);
    toast({ title: "نجاح", description: "تمت إضافة العقار بنجاح" });
    setIsAddOpen(false);
    setFormData({ type: 'سكني', unitsCount: 1 });
  };

  const handleDelete = (id: string) => {
    const propertyUnits = units.filter(u => u.propertyId === id);
    if (propertyUnits.length > 0) {
      toast({ title: "لا يمكن الحذف", description: "هذا العقار يحتوي على وحدات مرتبطة به", variant: "destructive" });
      return;
    }

    if(confirm("هل أنت متأكد من حذف هذا العقار؟")) {
      deleteProperty(id);
      toast({ title: "تم الحذف", description: "تم حذف العقار بنجاح" });
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground">العقارات</h1>
          <p className="text-muted-foreground mt-1">إدارة المجمعات والعمائر والفلل</p>
        </div>
        
        <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
          <DialogTrigger asChild>
            <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
              <Plus className="mr-2 h-4 w-4" />
              إضافة عقار جديد
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>إضافة عقار جديد</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="name">اسم العقار</Label>
                <Input id="name" value={formData.name || ''} onChange={e => setFormData({...formData, name: e.target.value})} placeholder="مثال: مجمع الرياض السكني" />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="owner">المالك</Label>
                <Select value={formData.ownerId} onValueChange={(val) => setFormData({...formData, ownerId: val})}>
                  <SelectTrigger>
                    <SelectValue placeholder="اختر المالك" />
                  </SelectTrigger>
                  <SelectContent>
                    {owners.map(owner => (
                      <SelectItem key={owner.id} value={owner.id}>{owner.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="type">النوع</Label>
                  <Select value={formData.type} onValueChange={(val: any) => setFormData({...formData, type: val})}>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر النوع" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="سكني">سكني</SelectItem>
                      <SelectItem value="تجاري">تجاري</SelectItem>
                      <SelectItem value="صناعي">صناعي</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="unitsCount">عدد الوحدات المتوقع</Label>
                  <Input id="unitsCount" type="number" min="1" value={formData.unitsCount || ''} onChange={e => setFormData({...formData, unitsCount: parseInt(e.target.value) || 0})} />
                </div>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="location">الموقع / العنوان</Label>
                <Input id="location" value={formData.location || ''} onChange={e => setFormData({...formData, location: e.target.value})} placeholder="المدينة، الحي، الشارع" />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAddOpen(false)}>إلغاء</Button>
              <Button onClick={handleSave}>حفظ البيانات</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="border-none shadow-sm">
        <CardHeader className="pb-3 border-b">
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
            <div className="relative w-full sm:w-96">
              <Search className="absolute right-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="البحث باسم العقار، المالك، أو الموقع..."
                className="pr-9 bg-muted/50 border-none"
              />
            </div>
            <div className="flex gap-2 w-full sm:w-auto">
              <Button variant="outline" className="flex-1 sm:flex-none">
                <Filter className="mr-2 h-4 w-4" />
                تصفية
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-right">
              <thead className="bg-muted/30">
                <tr className="border-b">
                  <th className="px-4 py-3 font-medium text-muted-foreground">رقم العقار</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">اسم العقار</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">النوع</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">المالك</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">الموقع</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">إجمالي الوحدات</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">نسبة الإشغال</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground w-[80px]">إجراءات</th>
                </tr>
              </thead>
              <tbody>
                {properties.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="text-center py-8 text-muted-foreground">لا يوجد عقارات مسجلة</td>
                  </tr>
                ) : properties.map((property) => {
                  const stats = getPropertyStats(property.id);
                  const occupancyRate = stats.unitsCount > 0 ? Math.round((stats.occupiedUnits / stats.unitsCount) * 100) : 0;
                  
                  let occupancyColor = "bg-emerald-500/10 text-emerald-500";
                  if (occupancyRate < 50) occupancyColor = "bg-destructive/10 text-destructive";
                  else if (occupancyRate < 80) occupancyColor = "bg-amber-500/10 text-amber-500";

                  return (
                    <tr 
                      key={property.id} 
                      className="border-b last:border-0 hover:bg-muted/20 transition-colors cursor-pointer"
                      onClick={() => setLocation(`/properties/${property.id}`)}
                    >
                      <td className="px-4 py-3 font-medium text-primary">{property.id}</td>
                      <td className="px-4 py-3 font-medium">{property.name}</td>
                      <td className="px-4 py-3">
                        <Badge variant="outline" className="font-normal bg-background">
                          {property.type}
                        </Badge>
                      </td>
                      <td className="px-4 py-3">{getOwnerName(property.ownerId)}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center text-muted-foreground">
                          <MapPin className="ml-1 h-3 w-3" />
                          <span className="truncate max-w-[150px]">{property.location}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 font-medium">{stats.unitsCount} <span className="text-xs text-muted-foreground font-normal">من أصل {property.unitsCount}</span></td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <span className={`px-2 py-0.5 rounded text-xs font-medium ${occupancyColor}`}>
                            {occupancyRate}%
                          </span>
                          <span className="text-xs text-muted-foreground">
                            ({stats.occupiedUnits}/{stats.unitsCount})
                          </span>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <span className="sr-only">فتح القائمة</span>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem className="cursor-pointer">
                              <Eye className="mr-2 h-4 w-4" />
                              <span>عرض التفاصيل</span>
                            </DropdownMenuItem>
                            <DropdownMenuItem className="cursor-pointer">
                              <Edit className="mr-2 h-4 w-4" />
                              <span>تعديل البيانات</span>
                            </DropdownMenuItem>
                            <DropdownMenuItem className="cursor-pointer text-destructive" onClick={() => handleDelete(property.id)}>
                              <Trash className="mr-2 h-4 w-4" />
                              <span>حذف</span>
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}