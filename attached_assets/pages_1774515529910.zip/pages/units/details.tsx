import { useParams, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, MapPin, Building2, User, Key, Gavel, FileText, Calendar } from "lucide-react";
import { useAppStore } from "@/store";

export default function UnitDetails() {
  const { id } = useParams();
  const { units, properties, contracts, maintenance, owners, tenants } = useAppStore();
  
  const unit = units.find(u => u.id === id);
  
  if (!unit) {
    return (
      <div className="flex flex-col items-center justify-center h-full space-y-4">
        <h2 className="text-2xl font-bold">الوحدة غير موجودة</h2>
        <Link href="/units"><Button variant="outline">العودة لقائمة الوحدات</Button></Link>
      </div>
    );
  }

  const property = properties.find(p => p.id === unit.propertyId);
  const owner = property ? owners.find(o => o.id === property.ownerId) : null;
  
  // Get all contracts for this unit
  const unitContracts = contracts.filter(c => c.unitId === id);
  const activeContract = unitContracts.find(c => c.status === 'ساري' || c.status === 'قارب على الانتهاء');
  const tenant = activeContract ? tenants.find(t => t.id === activeContract.tenantId) : null;

  // Get maintenance requests for this unit
  const unitMaintenance = maintenance.filter(m => m.unitId === id);

  let statusColor = "bg-muted text-muted-foreground";
  if (unit.status === 'مؤجرة') statusColor = "bg-emerald-500/10 text-emerald-500";
  else if (unit.status === 'شاغرة') statusColor = "bg-blue-500/10 text-blue-500";
  else if (unit.status === 'صيانة') statusColor = "bg-amber-500/10 text-amber-500";

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-4">
          <Link href="/units">
            <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
              <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-display font-bold text-foreground">وحدة: {unit.number}</h1>
            <div className="flex items-center gap-2 mt-1 text-muted-foreground text-sm">
              <span>رقم الوحدة: {unit.id}</span>
              <span>•</span>
              <Badge variant="secondary" className="font-normal">{unit.type}</Badge>
              <span>•</span>
              <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${statusColor}`}>
                {unit.status}
              </span>
            </div>
          </div>
        </div>
        <div className="flex gap-2">
          {!activeContract && unit.status === 'شاغرة' && (
            <Link href={`/contracts?unit=${unit.id}`}>
              <Button className="bg-primary text-primary-foreground">إنشاء عقد تأجير</Button>
            </Link>
          )}
          <Button variant="outline">تسجيل صيانة</Button>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <Card className="md:col-span-1 border-none shadow-sm h-fit">
          <CardHeader>
            <CardTitle>مواصفات الوحدة</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <span className="text-xs text-muted-foreground block mb-1">الدور</span>
                <span className="font-medium">{unit.floor}</span>
              </div>
              <div>
                <span className="text-xs text-muted-foreground block mb-1">الغرف</span>
                <span className="font-medium">{unit.rooms}</span>
              </div>
            </div>
            
            <div className="pt-3 border-t">
              <span className="text-xs text-muted-foreground block mb-1">القيمة الإيجارية التقديرية</span>
              <span className="font-bold text-lg text-primary">{unit.estimatedPrice.toLocaleString()} ﷼ <span className="text-sm font-normal text-muted-foreground">/ سنوياً</span></span>
            </div>

            <div className="pt-3 border-t space-y-3">
              <h4 className="font-semibold text-sm">العقار التابع</h4>
              {property ? (
                <div className="bg-muted/30 p-3 rounded-lg border border-border/50">
                  <Link href={`/properties/${property.id}`} className="font-bold text-primary hover:underline block mb-1">
                    {property.name}
                  </Link>
                  <div className="flex items-start gap-2 text-xs text-muted-foreground mt-2">
                    <MapPin className="h-3.5 w-3.5 shrink-0" />
                    <span>{property.location}</span>
                  </div>
                  {owner && (
                    <div className="flex items-center gap-2 text-xs text-muted-foreground mt-2">
                      <User className="h-3.5 w-3.5" />
                      <span>المالك: {owner.name}</span>
                    </div>
                  )}
                </div>
              ) : (
                <span className="text-sm text-muted-foreground">غير محدد</span>
              )}
            </div>
          </CardContent>
        </Card>

        <div className="md:col-span-2 space-y-6">
          <Card className="border-none shadow-sm">
            <CardHeader className="pb-3">
              <div className="flex justify-between items-center">
                <CardTitle className="flex items-center gap-2">
                  <Key className="h-5 w-5 text-primary" />
                  حالة التأجير الحالية
                </CardTitle>
                {activeContract && (
                  <Link href={`/contracts/${activeContract.id}`}>
                    <Button variant="ghost" size="sm">عرض العقد</Button>
                  </Link>
                )}
              </div>
            </CardHeader>
            <CardContent>
              {activeContract && tenant ? (
                <div className="flex flex-col sm:flex-row gap-6 p-4 border rounded-lg bg-emerald-50/30">
                  <div className="flex-1 space-y-1">
                    <p className="text-sm text-muted-foreground">المستأجر الحالي</p>
                    <Link href={`/tenants/${tenant.id}`} className="font-bold text-lg hover:underline">
                      {tenant.name}
                    </Link>
                    <p className="text-sm text-muted-foreground flex items-center gap-2 mt-1" dir="ltr">
                      <span>{tenant.phone}</span>
                    </p>
                  </div>
                  <div className="flex-1 space-y-1 sm:border-r sm:pr-6">
                    <p className="text-sm text-muted-foreground">تفاصيل العقد ({activeContract.id})</p>
                    <p className="font-medium text-lg">{activeContract.amount.toLocaleString()} ﷼ <span className="text-sm font-normal text-muted-foreground">({activeContract.paymentType})</span></p>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground mt-1">
                      <div className="flex items-center gap-1">
                        <Calendar className="h-3.5 w-3.5" />
                        <span>ينتهي: {activeContract.endDate}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-6 border rounded-lg bg-muted/20">
                  <p className="text-muted-foreground mb-3">الوحدة غير مؤجرة حالياً</p>
                  <Link href={`/contracts?unit=${unit.id}`}>
                    <Button>إنشاء عقد جديد</Button>
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="border-none shadow-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Gavel className="h-5 w-5 text-amber-500" />
                سجل الصيانة
              </CardTitle>
            </CardHeader>
            <CardContent>
              {unitMaintenance.length === 0 ? (
                <p className="text-center text-muted-foreground py-4">لا توجد طلبات صيانة مسجلة لهذه الوحدة</p>
              ) : (
                <div className="space-y-3">
                  {unitMaintenance.map(req => (
                    <div key={req.id} className="flex flex-col sm:flex-row justify-between items-start sm:items-center p-3 border rounded-lg hover:bg-muted/10">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium">{req.title}</span>
                          <Badge variant="outline" className={`text-xs font-normal ${
                            req.status === 'مكتمل' ? 'bg-emerald-500/10 text-emerald-500 border-emerald-200' :
                            req.status === 'قيد التنفيذ' ? 'bg-blue-500/10 text-blue-500 border-blue-200' :
                            'bg-amber-500/10 text-amber-500 border-amber-200'
                          }`}>
                            {req.status}
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground">{req.date} • {req.technician}</p>
                      </div>
                      <Link href={`/maintenance`}>
                        <Button variant="ghost" size="sm" className="mt-2 sm:mt-0">التفاصيل</Button>
                      </Link>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}