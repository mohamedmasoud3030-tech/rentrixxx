import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Plus, Search, Filter, MoreHorizontal, Eye, Edit, Trash, CheckCircle2, XCircle } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAppStore } from "@/store";
import { Unit } from "@/types";
import { useToast } from "@/hooks/use-toast";

export default function UnitsList() {
  const { units, properties, contracts, addUnit, updateUnit, deleteUnit } = useAppStore();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const [isAddOpen, setIsAddOpen] = useState(false);
  const [formData, setFormData] = useState<Partial<Unit>>({ type: 'شقة', status: 'شاغرة', rooms: 1, estimatedPrice: 0 });

  const getPropertyName = (propertyId: string) => {
    return properties.find(p => p.id === propertyId)?.name || 'غير معروف';
  };

  const getUnitContract = (unitId: string) => {
    const activeContract = contracts.find(c => c.unitId === unitId && (c.status === 'ساري' || c.status === 'قارب على الانتهاء'));
    return activeContract?.id || '-';
  };

  const handleSave = () => {
    if (!formData.number || !formData.propertyId || !formData.estimatedPrice) {
      toast({ title: "خطأ", description: "الرجاء تعبئة الحقول الأساسية (الرقم، العقار، القيمة التقديرية)", variant: "destructive" });
      return;
    }
    
    addUnit(formData as Omit<Unit, 'id'>);
    toast({ title: "نجاح", description: "تمت إضافة الوحدة بنجاح" });
    setIsAddOpen(false);
    setFormData({ type: 'شقة', status: 'شاغرة', rooms: 1, estimatedPrice: 0 });
  };

  const handleDelete = (id: string) => {
    const activeContract = contracts.find(c => c.unitId === id && (c.status === 'ساري' || c.status === 'قارب على الانتهاء'));
    if (activeContract) {
      toast({ title: "لا يمكن الحذف", description: "هذه الوحدة مرتبطة بعقد نشط", variant: "destructive" });
      return;
    }

    if(confirm("هل أنت متأكد من حذف هذه الوحدة؟")) {
      deleteUnit(id);
      toast({ title: "تم الحذف", description: "تم حذف الوحدة بنجاح" });
    }
  };

  const stats = {
    total: units.length,
    occupied: units.filter(u => u.status === 'مؤجرة').length,
    vacant: units.filter(u => u.status === 'شاغرة').length,
    maintenance: units.filter(u => u.status === 'صيانة').length,
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground">الوحدات</h1>
          <p className="text-muted-foreground mt-1">إدارة الشقق، المكاتب، والمعارض</p>
        </div>
        <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
          <DialogTrigger asChild>
            <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
              <Plus className="mr-2 h-4 w-4" />
              إضافة وحدة جديدة
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>إضافة وحدة جديدة</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="propertyId">العقار التابع له</Label>
                <Select value={formData.propertyId} onValueChange={(val) => setFormData({...formData, propertyId: val})}>
                  <SelectTrigger>
                    <SelectValue placeholder="اختر العقار" />
                  </SelectTrigger>
                  <SelectContent>
                    {properties.map(prop => (
                      <SelectItem key={prop.id} value={prop.id}>{prop.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="number">رقم / اسم الوحدة</Label>
                  <Input id="number" value={formData.number || ''} onChange={e => setFormData({...formData, number: e.target.value})} placeholder="مثال: شقة 101" />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="type">النوع</Label>
                  <Select value={formData.type} onValueChange={(val: any) => setFormData({...formData, type: val})}>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر النوع" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="شقة">شقة</SelectItem>
                      <SelectItem value="مكتب">مكتب</SelectItem>
                      <SelectItem value="معرض">معرض</SelectItem>
                      <SelectItem value="مستودع">مستودع</SelectItem>
                      <SelectItem value="فيلا">فيلا</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="floor">الدور</Label>
                  <Input id="floor" value={formData.floor || ''} onChange={e => setFormData({...formData, floor: e.target.value})} placeholder="الدور الأول" />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="rooms">الغرف</Label>
                  <Input id="rooms" type="number" min="0" value={formData.rooms || ''} onChange={e => setFormData({...formData, rooms: parseInt(e.target.value) || 0})} />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="status">الحالة</Label>
                  <Select value={formData.status} onValueChange={(val: any) => setFormData({...formData, status: val})}>
                    <SelectTrigger>
                      <SelectValue placeholder="الحالة" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="شاغرة">شاغرة</SelectItem>
                      <SelectItem value="مؤجرة">مؤجرة</SelectItem>
                      <SelectItem value="صيانة">صيانة</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="estimatedPrice">القيمة التقديرية (سنوياً)</Label>
                <div className="relative">
                  <Input id="estimatedPrice" type="number" value={formData.estimatedPrice || ''} onChange={e => setFormData({...formData, estimatedPrice: parseInt(e.target.value) || 0})} className="pl-12" />
                  <div className="absolute left-3 top-2.5 text-muted-foreground text-sm">﷼</div>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAddOpen(false)}>إلغاء</Button>
              <Button onClick={handleSave}>حفظ البيانات</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="border-none shadow-sm bg-card">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">إجمالي الوحدات</p>
              <p className="text-2xl font-bold">{stats.total}</p>
            </div>
            <div className="p-2 bg-primary/10 rounded-lg">
              <span className="text-primary font-bold">∑</span>
            </div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm bg-card">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">مؤجرة</p>
              <p className="text-2xl font-bold">{stats.occupied}</p>
            </div>
            <div className="p-2 bg-emerald-500/10 rounded-lg">
              <CheckCircle2 className="h-5 w-5 text-emerald-500" />
            </div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm bg-card">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">شاغرة</p>
              <p className="text-2xl font-bold">{stats.vacant}</p>
            </div>
            <div className="p-2 bg-blue-500/10 rounded-lg">
              <span className="text-blue-500 font-bold">○</span>
            </div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm bg-card">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">صيانة / موقوفة</p>
              <p className="text-2xl font-bold">{stats.maintenance}</p>
            </div>
            <div className="p-2 bg-amber-500/10 rounded-lg">
              <XCircle className="h-5 w-5 text-amber-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-none shadow-sm">
        <CardHeader className="pb-3 border-b">
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
            <div className="relative w-full sm:w-96">
              <Search className="absolute right-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="البحث برقم الوحدة، العقار..."
                className="pr-9 bg-muted/50 border-none"
              />
            </div>
            <Button variant="outline" className="w-full sm:w-auto">
              <Filter className="mr-2 h-4 w-4" />
              تصفية
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-right">
              <thead className="bg-muted/30">
                <tr className="border-b">
                  <th className="px-4 py-3 font-medium text-muted-foreground">رقم الوحدة</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">الرقم/الاسم</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">العقار التابع</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">النوع</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">القيمة التقديرية</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">الحالة</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">العقد الحالي</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground w-[80px]">إجراءات</th>
                </tr>
              </thead>
              <tbody>
                {units.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="text-center py-8 text-muted-foreground">لا يوجد وحدات مسجلة</td>
                  </tr>
                ) : units.map((unit) => {
                  let statusColor = "bg-muted text-muted-foreground";
                  if (unit.status === "مؤجرة") statusColor = "bg-emerald-500/10 text-emerald-500";
                  else if (unit.status === "شاغرة") statusColor = "bg-blue-500/10 text-blue-500";
                  else if (unit.status === "صيانة") statusColor = "bg-amber-500/10 text-amber-500";

                  const contract = getUnitContract(unit.id);

                  return (
                    <tr 
                      key={unit.id} 
                      className="border-b last:border-0 hover:bg-muted/20 transition-colors cursor-pointer"
                      onClick={() => setLocation(`/units/${unit.id}`)}
                    >
                      <td className="px-4 py-3 font-medium text-primary">{unit.id}</td>
                      <td className="px-4 py-3 font-medium">{unit.number}</td>
                      <td className="px-4 py-3">{getPropertyName(unit.propertyId)}</td>
                      <td className="px-4 py-3">{unit.type}</td>
                      <td className="px-4 py-3 font-medium">{unit.estimatedPrice.toLocaleString()} ﷼</td>
                      <td className="px-4 py-3">
                        <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${statusColor}`}>
                          {unit.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-muted-foreground">
                        {contract !== "-" ? (
                          <span className="text-primary hover:underline cursor-pointer">{contract}</span>
                        ) : "-"}
                      </td>
                      <td className="px-4 py-3">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <span className="sr-only">فتح القائمة</span>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem className="cursor-pointer">
                              <Eye className="mr-2 h-4 w-4" />
                              <span>عرض التفاصيل</span>
                            </DropdownMenuItem>
                            <DropdownMenuItem className="cursor-pointer">
                              <Edit className="mr-2 h-4 w-4" />
                              <span>تعديل البيانات</span>
                            </DropdownMenuItem>
                            {contract === "-" && (
                              <DropdownMenuItem className="cursor-pointer text-destructive" onClick={() => handleDelete(unit.id)}>
                                <Trash className="mr-2 h-4 w-4" />
                                <span>حذف</span>
                              </DropdownMenuItem>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}