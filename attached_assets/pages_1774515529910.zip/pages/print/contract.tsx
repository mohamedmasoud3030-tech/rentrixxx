import { useParams, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useAppStore } from "@/store";
import { useEffect } from "react";
import { ArrowRight, Printer } from "lucide-react";

export default function PrintContract() {
  const { id } = useParams();
  const { contracts, tenants, units, properties } = useAppStore();
  
  const contract = contracts.find(c => c.id === id);
  const tenant = contract ? tenants.find(t => t.id === contract.tenantId) : null;
  const unit = contract ? units.find(u => u.id === contract.unitId) : null;
  const property = unit ? properties.find(p => p.id === unit.propertyId) : null;

  useEffect(() => {
    const timer = setTimeout(() => {
      window.print();
    }, 500);
    return () => clearTimeout(timer);
  }, []);

  if (!contract) {
    return <div className="p-8 text-center">العقد غير موجود</div>;
  }

  return (
    <div className="bg-white min-h-screen text-black p-8 font-sans leading-relaxed" dir="rtl">
      <div className="no-print mb-8 flex justify-between items-center bg-muted/20 p-4 rounded-lg">
        <Link href={`/contracts/${id}`}>
          <Button variant="outline"><ArrowRight className="ml-2 h-4 w-4" /> العودة للتفاصيل</Button>
        </Link>
        <Button onClick={() => window.print()}><Printer className="ml-2 h-4 w-4" /> طباعة</Button>
      </div>

      <div className="max-w-4xl mx-auto border-2 border-black p-10 bg-white">
        <div className="print-header text-center mb-10 pb-6 border-b-2 border-black">
          <h1 className="text-3xl font-bold mb-2">عقد إيجار موحد</h1>
          <p className="text-lg font-bold">رقم العقد: {contract.id}</p>
        </div>

        <div className="mb-6 space-y-2">
          <p>إنه في يوم الموافق {new Date().toISOString().split('T')[0]} تم إبرام هذا العقد بين كل من:</p>
        </div>

        <div className="mb-8 border border-black rounded p-4">
          <h3 className="font-bold text-lg mb-3 underline">الطرف الأول (المؤجر)</h3>
          <div className="grid grid-cols-2 gap-4">
            <p><span className="font-bold">الاسم:</span> شركة رينتريكس لإدارة الأملاك</p>
            <p><span className="font-bold">السجل التجاري:</span> 1010123456</p>
            <p><span className="font-bold">العنوان:</span> الرياض، حي العليا، طريق الملك فهد</p>
            <p><span className="font-bold">الصفة:</span> وكيل / مدير أملاك</p>
          </div>
        </div>

        <div className="mb-8 border border-black rounded p-4">
          <h3 className="font-bold text-lg mb-3 underline">الطرف الثاني (المستأجر)</h3>
          <div className="grid grid-cols-2 gap-4">
            <p><span className="font-bold">الاسم:</span> {tenant?.name}</p>
            <p><span className="font-bold">الهوية/السجل:</span> {tenant?.nationalId}</p>
            <p><span className="font-bold">الجوال:</span> <span dir="ltr">{tenant?.phone}</span></p>
            {tenant?.contact && <p><span className="font-bold">المفوض:</span> {tenant.contact}</p>}
          </div>
        </div>

        <div className="mb-8">
          <h3 className="font-bold text-lg mb-3 underline">البند الأول: العين المؤجرة</h3>
          <p className="mb-2">أجر الطرف الأول للطرف الثاني الوحدة العقارية الموصوفة أدناه، وقد قبل الطرف الثاني استئجارها بحالتها الراهنة:</p>
          <table className="w-full border-collapse border border-black mt-3">
            <tbody>
              <tr>
                <td className="border border-black p-2 font-bold w-1/4 bg-gray-100">رقم / اسم الوحدة</td>
                <td className="border border-black p-2 w-1/4">{unit?.number}</td>
                <td className="border border-black p-2 font-bold w-1/4 bg-gray-100">النوع</td>
                <td className="border border-black p-2 w-1/4">{unit?.type}</td>
              </tr>
              <tr>
                <td className="border border-black p-2 font-bold bg-gray-100">المشروع/العقار</td>
                <td className="border border-black p-2" colSpan={3}>{property?.name} - {property?.location}</td>
              </tr>
            </tbody>
          </table>
        </div>

        <div className="mb-8">
          <h3 className="font-bold text-lg mb-3 underline">البند الثاني: مدة العقد</h3>
          <p>
            مدة هذا العقد سنة واحدة تبدأ من تاريخ <span className="font-bold">{contract.startDate}</span> وتنتهي في تاريخ <span className="font-bold">{contract.endDate}</span>.
            ولا يجدد العقد إلا بموافقة كتابية من الطرفين أو بإبرام عقد جديد.
          </p>
        </div>

        <div className="mb-8">
          <h3 className="font-bold text-lg mb-3 underline">البند الثالث: القيمة الإيجارية وطريقة الدفع</h3>
          <p className="mb-2">اتفق الطرفان على أن تكون القيمة الإيجارية السنوية <span className="font-bold text-lg bg-gray-200 px-2 py-1 mx-1">{contract.amount.toLocaleString()} ﷼</span>.</p>
          <p className="mb-2">وتدفع على النحو التالي: <span className="font-bold">{contract.paymentType}</span>.</p>
        </div>

        <div className="mb-8">
          <h3 className="font-bold text-lg mb-3 underline">البند الرابع: التزامات الطرف الثاني (المستأجر)</h3>
          <ol className="list-decimal list-inside space-y-2 pr-4">
            <li>يلتزم المستأجر بالمحافظة على العين المؤجرة واستخدامها للغرض المخصص لها فقط.</li>
            <li>عدم إجراء أي تعديلات جوهرية أو هدم أو بناء بدون موافقة كتابية مسبقة من المؤجر.</li>
            <li>سداد فواتير الكهرباء والمياه والخدمات الخاصة بالوحدة خلال مدة سريان العقد.</li>
            <li>تسليم الوحدة عند نهاية العقد بحالة جيدة كما استلمها مع مراعاة الاستهلاك الطبيعي.</li>
          </ol>
        </div>

        <div className="mt-16 grid grid-cols-2 gap-8 text-center">
          <div>
            <h4 className="font-bold mb-8">الطرف الأول (المؤجر)</h4>
            <p>التوقيع: ____________________</p>
            <p className="mt-4">الختم:</p>
          </div>
          <div>
            <h4 className="font-bold mb-8">الطرف الثاني (المستأجر)</h4>
            <p>التوقيع: ____________________</p>
            <p className="mt-4">الختم (للشركات):</p>
          </div>
        </div>
      </div>
    </div>
  );
}