import { useParams, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useAppStore } from "@/store";
import { useEffect } from "react";
import { ArrowRight, Printer } from "lucide-react";

export default function PrintInvoice() {
  const { id } = useParams();
  const { invoices, contracts, tenants, units, properties } = useAppStore();
  
  const invoice = invoices.find(i => i.id === id);
  const contract = invoice ? contracts.find(c => c.id === invoice.contractId) : null;
  const tenant = invoice ? tenants.find(t => t.id === invoice.tenantId) : null;
  const unit = contract ? units.find(u => u.id === contract.unitId) : null;
  const property = unit ? properties.find(p => p.id === unit.propertyId) : null;

  useEffect(() => {
    // Automatically open print dialog after a short delay
    const timer = setTimeout(() => {
      window.print();
    }, 500);
    return () => clearTimeout(timer);
  }, []);

  if (!invoice) {
    return <div className="p-8 text-center">الفاتورة غير موجودة</div>;
  }

  return (
    <div className="bg-white min-h-screen text-black p-8 font-sans" dir="rtl">
      <div className="no-print mb-8 flex justify-between items-center bg-muted/20 p-4 rounded-lg">
        <Link href={`/invoices/${id}`}>
          <Button variant="outline"><ArrowRight className="ml-2 h-4 w-4" /> العودة للتفاصيل</Button>
        </Link>
        <Button onClick={() => window.print()}><Printer className="ml-2 h-4 w-4" /> طباعة</Button>
      </div>

      <div className="max-w-4xl mx-auto border p-8 bg-white">
        <div className="print-header flex justify-between items-end border-b-2 border-black pb-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-1">شركة رينتريكس لإدارة الأملاك</h1>
            <p className="text-gray-600">س.ت: 1010123456 | الرقم الضريبي: 300123456700003</p>
          </div>
          <div className="text-left">
            <h2 className="text-4xl font-bold text-gray-800">فاتورة ضريبية</h2>
            <p className="text-lg mt-2 font-bold">رقم: {invoice.id}</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-8 mb-8">
          <div className="border border-gray-300 rounded p-4">
            <h3 className="font-bold border-b border-gray-200 pb-2 mb-3 text-lg">مطلوبة من (المستأجر)</h3>
            <p className="font-bold text-lg mb-1">{tenant?.name}</p>
            <p className="mb-1 text-gray-700">رقم الهوية/السجل: {tenant?.nationalId}</p>
            <p className="text-gray-700">الجوال: <span dir="ltr">{tenant?.phone}</span></p>
          </div>
          
          <div className="border border-gray-300 rounded p-4">
            <h3 className="font-bold border-b border-gray-200 pb-2 mb-3 text-lg">تفاصيل الفاتورة</h3>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-600">تاريخ الإصدار:</span>
                <span className="font-medium">{new Date().toISOString().split('T')[0]}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">تاريخ الاستحقاق:</span>
                <span className="font-bold">{invoice.dueDate}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">رقم العقد:</span>
                <span className="font-medium">{contract?.id}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="mb-8">
          <table className="w-full border-collapse border border-gray-400">
            <thead>
              <tr className="bg-gray-100">
                <th className="border border-gray-400 p-3 text-right w-12">#</th>
                <th className="border border-gray-400 p-3 text-right">البيان</th>
                <th className="border border-gray-400 p-3 text-right">العين المؤجرة</th>
                <th className="border border-gray-400 p-3 text-left w-48">المبلغ (غير شامل الضريبة)</th>
                <th className="border border-gray-400 p-3 text-left w-32">الضريبة (15%)</th>
                <th className="border border-gray-400 p-3 text-left w-40">الإجمالي</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="border border-gray-400 p-3 text-right">1</td>
                <td className="border border-gray-400 p-3">
                  <p className="font-bold">دفعة إيجارية</p>
                  <p className="text-sm text-gray-600 mt-1">حسب العقد رقم {contract?.id}</p>
                </td>
                <td className="border border-gray-400 p-3">
                  {unit?.number} - {property?.name}
                </td>
                {/* Simplified tax calculation for mockup */}
                <td className="border border-gray-400 p-3 text-left">{Math.round(invoice.amount / 1.15).toLocaleString()} ﷼</td>
                <td className="border border-gray-400 p-3 text-left">{Math.round(invoice.amount - (invoice.amount / 1.15)).toLocaleString()} ﷼</td>
                <td className="border border-gray-400 p-3 text-left font-bold">{invoice.amount.toLocaleString()} ﷼</td>
              </tr>
            </tbody>
          </table>
        </div>

        <div className="flex justify-end mb-12">
          <div className="w-1/3 border border-gray-400 rounded">
            <div className="flex justify-between p-3 border-b border-gray-200">
              <span className="text-gray-600">الإجمالي (قبل الضريبة)</span>
              <span>{Math.round(invoice.amount / 1.15).toLocaleString()} ﷼</span>
            </div>
            <div className="flex justify-between p-3 border-b border-gray-200">
              <span className="text-gray-600">قيمة الضريبة المضافة (15%)</span>
              <span>{Math.round(invoice.amount - (invoice.amount / 1.15)).toLocaleString()} ﷼</span>
            </div>
            <div className="flex justify-between p-4 bg-gray-100 font-bold text-xl rounded-b">
              <span>الإجمالي المستحق</span>
              <span>{invoice.amount.toLocaleString()} ﷼</span>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-300 pt-4 mt-8">
          <h4 className="font-bold mb-2">تعليمات الدفع:</h4>
          <p className="text-sm text-gray-600 mb-1">1. الرجاء سداد المبلغ المستحق قبل تاريخ الاستحقاق لتجنب الغرامات.</p>
          <p className="text-sm text-gray-600 mb-1">2. التحويل البنكي: بنك الراجحي - حساب رقم SA0180000000000123456789</p>
          <p className="text-sm text-gray-600">3. يرجى إرسال إيصال التحويل مع ذكر رقم الفاتورة في الملاحظات.</p>
        </div>
      </div>
    </div>
  );
}