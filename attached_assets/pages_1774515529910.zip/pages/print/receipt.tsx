import { useParams, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useAppStore } from "@/store";
import { useEffect } from "react";
import { ArrowRight, Printer } from "lucide-react";

export default function PrintReceipt() {
  const { id } = useParams();
  const { receipts, invoices, tenants, contracts, units, properties } = useAppStore();
  
  const receipt = receipts.find(r => r.id === id);
  const tenant = receipt ? tenants.find(t => t.id === receipt.tenantId) : null;
  const invoice = receipt?.invoiceId ? invoices.find(i => i.id === receipt.invoiceId) : null;
  const contract = invoice ? contracts.find(c => c.id === invoice.contractId) : null;
  const unit = contract ? units.find(u => u.id === contract.unitId) : null;
  const property = unit ? properties.find(p => p.id === unit.propertyId) : null;

  useEffect(() => {
    const timer = setTimeout(() => {
      window.print();
    }, 500);
    return () => clearTimeout(timer);
  }, []);

  if (!receipt) {
    return <div className="p-8 text-center">السند غير موجود</div>;
  }

  return (
    <div className="bg-white min-h-screen text-black p-8 font-sans" dir="rtl">
      <div className="no-print mb-8 flex justify-between items-center bg-muted/20 p-4 rounded-lg">
        <Link href={`/receipts/${id}`}>
          <Button variant="outline"><ArrowRight className="ml-2 h-4 w-4" /> العودة للتفاصيل</Button>
        </Link>
        <Button onClick={() => window.print()}><Printer className="ml-2 h-4 w-4" /> طباعة</Button>
      </div>

      <div className="max-w-3xl mx-auto border-2 border-black p-8 bg-white relative">
        {/* Watermark for canceled receipts */}
        {receipt.status === 'ملغي' && (
          <div className="absolute inset-0 flex items-center justify-center opacity-10 pointer-events-none transform -rotate-45">
            <span className="text-9xl font-bold text-red-600">ملغي</span>
          </div>
        )}

        <div className="flex justify-between items-start border-b-2 border-black pb-6 mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-2">شركة رينتريكس لإدارة الأملاك</h1>
            <p className="text-gray-600">الرياض، طريق الملك فهد</p>
            <p className="text-gray-600">هاتف: 920012345</p>
          </div>
          <div className="text-left bg-gray-100 p-4 border border-gray-300 rounded text-center min-w-[200px]">
            <h2 className="text-2xl font-bold text-gray-800 mb-2">سند قبض</h2>
            <p className="text-sm">رقم السند: <span className="font-bold text-lg">{receipt.id}</span></p>
            <p className="text-sm mt-1">التاريخ: <span className="font-bold">{receipt.date}</span></p>
          </div>
        </div>

        <div className="space-y-6 text-lg leading-relaxed">
          <div className="flex items-end gap-2 border-b border-gray-300 pb-2">
            <span className="font-bold min-w-[150px]">استلمنا من المكرم / السادة:</span>
            <span className="flex-1 font-bold text-xl">{tenant?.name}</span>
          </div>

          <div className="flex items-end gap-2 border-b border-gray-300 pb-2">
            <span className="font-bold min-w-[150px]">مبلغاً وقدره:</span>
            <span className="flex-1 font-bold">{receipt.amount.toLocaleString()} ﷼</span>
            <span className="text-sm text-gray-600">(فقط {receipt.amount} ريال سعودي لا غير)</span>
          </div>

          <div className="flex items-end gap-2 border-b border-gray-300 pb-2">
            <span className="font-bold min-w-[150px]">وذلك عن:</span>
            <span className="flex-1">
              {invoice ? (
                `سداد فاتورة رقم ${invoice.id} (عقد رقم ${contract?.id}) - ${unit?.number} في ${property?.name}`
              ) : (
                'دفعة مقدمة تحت الحساب / أخرى'
              )}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-8 border-b border-gray-300 pb-4 pt-4">
            <div className="flex gap-2">
              <span className="font-bold min-w-[100px]">طريقة الدفع:</span>
              <span>{receipt.method}</span>
            </div>
            {receipt.reference && (
              <div className="flex gap-2">
                <span className="font-bold min-w-[120px]">الرقم المرجعي:</span>
                <span dir="ltr">{receipt.reference}</span>
              </div>
            )}
          </div>
        </div>

        <div className="mt-16 pt-8 grid grid-cols-2 gap-8 text-center">
          <div>
            <h4 className="font-bold mb-8">المستلم (المحاسب)</h4>
            <p>الاسم: ____________________</p>
            <p className="mt-4">التوقيع: ____________________</p>
          </div>
          <div>
            <h4 className="font-bold mb-8">الختم الرسمي</h4>
            <div className="w-32 h-32 border-2 border-dashed border-gray-300 rounded-full mx-auto flex items-center justify-center text-gray-400">
              مكان الختم
            </div>
          </div>
        </div>
        
        <div className="mt-8 pt-4 border-t border-gray-200 text-center text-sm text-gray-500">
          هذا السند إلكتروني ومعتمد من قبل النظام.
        </div>
      </div>
    </div>
  );
}