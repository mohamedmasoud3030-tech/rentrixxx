import { useParams, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useAppStore } from "@/store";
import { useEffect } from "react";
import { ArrowRight, Printer } from "lucide-react";

export default function PrintMaintenance() {
  const { id } = useParams();
  const { maintenance, properties, units, tenants, contracts } = useAppStore();
  
  const request = maintenance.find(m => m.id === id);
  const property = request ? properties.find(p => p.id === request.propertyId) : null;
  const unit = request && request.unitId !== '-' ? units.find(u => u.id === request.unitId) : null;
  
  let tenant = null;
  if (unit) {
    const activeContract = contracts.find(c => c.unitId === unit.id && (c.status === 'ساري' || c.status === 'قارب على الانتهاء'));
    if (activeContract) {
      tenant = tenants.find(t => t.id === activeContract.tenantId);
    }
  }

  useEffect(() => {
    const timer = setTimeout(() => {
      window.print();
    }, 500);
    return () => clearTimeout(timer);
  }, []);

  if (!request) {
    return <div className="p-8 text-center">طلب الصيانة غير موجود</div>;
  }

  return (
    <div className="bg-white min-h-screen text-black p-8 font-sans" dir="rtl">
      <div className="no-print mb-8 flex justify-between items-center bg-muted/20 p-4 rounded-lg">
        <Link href={`/maintenance/${id}`}>
          <Button variant="outline"><ArrowRight className="ml-2 h-4 w-4" /> العودة للتفاصيل</Button>
        </Link>
        <Button onClick={() => window.print()}><Printer className="ml-2 h-4 w-4" /> طباعة</Button>
      </div>

      <div className="max-w-4xl mx-auto border-2 border-black p-8 bg-white">
        <div className="text-center border-b-2 border-black pb-4 mb-6">
          <h1 className="text-3xl font-bold mb-2">أمر عمل صيانة (Work Order)</h1>
          <p className="text-lg">رقم الطلب: <span className="font-bold">{request.id}</span></p>
        </div>

        <div className="grid grid-cols-2 gap-8 mb-8">
          <div>
            <table className="w-full text-right border-collapse">
              <tbody>
                <tr className="border-b border-gray-300">
                  <td className="py-2 font-bold w-32 text-gray-600">تاريخ الطلب:</td>
                  <td className="py-2">{request.date}</td>
                </tr>
                <tr className="border-b border-gray-300">
                  <td className="py-2 font-bold text-gray-600">الأولوية:</td>
                  <td className="py-2 font-bold">{request.priority}</td>
                </tr>
                <tr className="border-b border-gray-300">
                  <td className="py-2 font-bold text-gray-600">الحالة:</td>
                  <td className="py-2">{request.status}</td>
                </tr>
              </tbody>
            </table>
          </div>
          <div>
            <table className="w-full text-right border-collapse">
              <tbody>
                <tr className="border-b border-gray-300">
                  <td className="py-2 font-bold w-32 text-gray-600">الموقع:</td>
                  <td className="py-2">{property?.name} - {property?.location}</td>
                </tr>
                <tr className="border-b border-gray-300">
                  <td className="py-2 font-bold text-gray-600">الوحدة:</td>
                  <td className="py-2">{unit ? unit.number : 'مرافق مشتركة'}</td>
                </tr>
                <tr className="border-b border-gray-300">
                  <td className="py-2 font-bold text-gray-600">المبلغ/المستأجر:</td>
                  <td className="py-2">{tenant ? `${tenant.name} (${tenant.phone})` : 'الإدارة'}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div className="mb-8 border border-black rounded">
          <div className="bg-gray-100 p-3 border-b border-black font-bold">وصف المشكلة / المطلوب:</div>
          <div className="p-4 min-h-[100px]">
            <h4 className="font-bold mb-2">{request.title}</h4>
            <p>{request.description}</p>
          </div>
        </div>

        <div className="mb-8 border border-black rounded">
          <div className="bg-gray-100 p-3 border-b border-black font-bold">توجيهات الإدارة / الفني المكلف:</div>
          <div className="p-4 flex gap-4">
            <span className="font-bold">اسم الفني / الشركة:</span>
            <span>{request.technician !== 'لم يحدد' ? request.technician : '________________________'}</span>
          </div>
        </div>

        <div className="mb-8 border border-black rounded min-h-[200px]">
          <div className="bg-gray-100 p-3 border-b border-black font-bold flex justify-between">
            <span>تقرير الإنجاز (يُعبأ من قبل الفني):</span>
          </div>
          <div className="p-4 space-y-8">
            <p className="border-b border-dashed border-gray-400 pb-1 w-full text-white select-none">.</p>
            <p className="border-b border-dashed border-gray-400 pb-1 w-full text-white select-none">.</p>
            <p className="border-b border-dashed border-gray-400 pb-1 w-full text-white select-none">.</p>
            <div className="grid grid-cols-2 gap-4 mt-6">
              <p>مواد تم استخدامها / شراؤها: ____________________</p>
              <p>التكلفة الإجمالية التقديرية: ____________________</p>
            </div>
          </div>
        </div>

        <div className="mt-8 grid grid-cols-3 gap-8 text-center pt-8 border-t-2 border-black">
          <div>
            <h4 className="font-bold mb-6">توقيع المستأجر بالاستلام</h4>
            <p>___________________</p>
          </div>
          <div>
            <h4 className="font-bold mb-6">توقيع الفني المنفذ</h4>
            <p>___________________</p>
          </div>
          <div>
            <h4 className="font-bold mb-6">اعتماد الإدارة</h4>
            <p>___________________</p>
          </div>
        </div>
      </div>
    </div>
  );
}