import { useParams, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowRight, User, Home, MapPin, Calendar, CreditCard, FileText, CheckCircle2, AlertCircle, Clock, Printer } from "lucide-react";
import { useAppStore } from "@/store";

export default function ContractDetails() {
  const { id } = useParams();
  const { contracts, tenants, units, properties, invoices, receipts } = useAppStore();
  
  const contract = contracts.find(c => c.id === id);
  
  if (!contract) {
    return (
      <div className="flex flex-col items-center justify-center h-full space-y-4">
        <h2 className="text-2xl font-bold">العقد غير موجود</h2>
        <Link href="/contracts"><Button variant="outline">العودة لقائمة العقود</Button></Link>
      </div>
    );
  }

  const tenant = tenants.find(t => t.id === contract.tenantId);
  const unit = units.find(u => u.id === contract.unitId);
  const property = unit ? properties.find(p => p.id === unit.propertyId) : null;
  
  const contractInvoices = invoices.filter(i => i.contractId === id && i.status !== 'ملغاة');
  
  // Calculate financials for this specific contract
  const totalInvoiced = contractInvoices.reduce((sum, i) => sum + i.amount, 0);
  const totalPaid = contractInvoices.reduce((sum, i) => sum + i.paid, 0);
  const totalRemaining = Math.max(0, totalInvoiced - totalPaid);

  let statusColor = "bg-muted text-muted-foreground";
  if (contract.status === "ساري") statusColor = "bg-emerald-500/10 text-emerald-500 border-emerald-200";
  else if (contract.status === "قارب على الانتهاء") statusColor = "bg-amber-500/10 text-amber-500 border-amber-200";
  else if (contract.status === "ملغي") statusColor = "bg-destructive/10 text-destructive border-destructive/20";
  else if (contract.status === "منتهي") statusColor = "bg-muted text-muted-foreground border-border";

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-4">
          <Link href="/contracts">
            <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
              <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-display font-bold text-foreground">عقد رقم: {contract.id}</h1>
            <div className="flex items-center gap-2 mt-1">
              <Badge variant="outline" className={`font-normal ${statusColor}`}>
                {contract.status}
              </Badge>
              <span className="text-muted-foreground text-sm">•</span>
              <span className="text-muted-foreground text-sm">تاريخ البداية: {contract.startDate}</span>
            </div>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="bg-background">
            <Printer className="mr-2 h-4 w-4" />
            طباعة العقد
          </Button>
          {(contract.status === 'ساري' || contract.status === 'قارب على الانتهاء') && (
            <Button className="bg-primary text-primary-foreground">تجديد العقد</Button>
          )}
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-6">
          <div className="grid sm:grid-cols-2 gap-4">
            <Card className="border-none shadow-sm">
              <CardContent className="p-4 flex items-start gap-4">
                <div className="p-3 bg-primary/10 rounded-xl">
                  <User className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1">الطرف الثاني (المستأجر)</p>
                  {tenant ? (
                    <>
                      <Link href={`/tenants/${tenant.id}`} className="font-bold text-lg hover:underline block">
                        {tenant.name}
                      </Link>
                      <p className="text-xs text-muted-foreground mt-1" dir="ltr">{tenant.phone}</p>
                    </>
                  ) : (
                    <span className="font-medium">غير معروف</span>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className="border-none shadow-sm">
              <CardContent className="p-4 flex items-start gap-4">
                <div className="p-3 bg-blue-500/10 rounded-xl">
                  <Home className="h-6 w-6 text-blue-500" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1">بيانات العين المؤجرة</p>
                  {unit ? (
                    <>
                      <Link href={`/units/${unit.id}`} className="font-bold text-lg hover:underline block">
                        {unit.number} <span className="text-sm font-normal text-muted-foreground">({unit.type})</span>
                      </Link>
                      {property && (
                        <p className="text-xs text-muted-foreground mt-1 truncate max-w-[200px]">{property.name} - {property.location}</p>
                      )}
                    </>
                  ) : (
                    <span className="font-medium">غير معروف</span>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="border-none shadow-sm">
            <CardHeader className="pb-3 border-b">
              <CardTitle>الدفعات والفواتير المرتبطة</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              {contractInvoices.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <FileText className="h-12 w-12 text-muted-foreground/30 mx-auto mb-3" />
                  <p>لا توجد فواتير مصدرة على هذا العقد</p>
                  <Button variant="outline" className="mt-4" size="sm">إصدار الفاتورة الأولى</Button>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm text-right">
                    <thead className="bg-muted/30">
                      <tr className="border-b">
                        <th className="px-4 py-3 font-medium text-muted-foreground">رقم الفاتورة</th>
                        <th className="px-4 py-3 font-medium text-muted-foreground">تاريخ الاستحقاق</th>
                        <th className="px-4 py-3 font-medium text-muted-foreground">المبلغ</th>
                        <th className="px-4 py-3 font-medium text-muted-foreground">المدفوع</th>
                        <th className="px-4 py-3 font-medium text-muted-foreground">الحالة</th>
                      </tr>
                    </thead>
                    <tbody>
                      {contractInvoices.map(invoice => {
                        let invStatusColor = "bg-muted text-muted-foreground";
                        if (invoice.status === "مدفوع") invStatusColor = "bg-emerald-500/10 text-emerald-500";
                        else if (invoice.status === "مدفوع جزئياً") invStatusColor = "bg-blue-500/10 text-blue-500";
                        else if (invoice.status === "مستحق") invStatusColor = "bg-amber-500/10 text-amber-500";
                        else if (invoice.status === "متأخر") invStatusColor = "bg-destructive/10 text-destructive";

                        return (
                          <tr key={invoice.id} className="border-b last:border-0 hover:bg-muted/20">
                            <td className="px-4 py-3 font-medium">{invoice.id}</td>
                            <td className="px-4 py-3 text-muted-foreground">{invoice.dueDate}</td>
                            <td className="px-4 py-3 font-medium">{invoice.amount.toLocaleString()} ﷼</td>
                            <td className="px-4 py-3 text-emerald-600">{invoice.paid.toLocaleString()} ﷼</td>
                            <td className="px-4 py-3">
                              <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${invStatusColor}`}>
                                {invoice.status}
                              </span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="border-none shadow-sm bg-card h-fit">
            <CardHeader className="pb-3 border-b">
              <CardTitle>تفاصيل العقد المالي</CardTitle>
            </CardHeader>
            <CardContent className="pt-4 space-y-4">
              <div className="flex justify-between items-center text-sm">
                <span className="text-muted-foreground">القيمة الإيجارية السنوية:</span>
                <span className="font-bold text-lg">{contract.amount.toLocaleString()} ﷼</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-muted-foreground">نظام الدفعات:</span>
                <span className="font-medium">{contract.paymentType}</span>
              </div>
              
              <div className="my-2 border-t pt-4 space-y-3">
                <div className="flex justify-between items-center text-sm">
                  <span className="text-muted-foreground flex items-center gap-1">
                    <FileText className="h-3.5 w-3.5" /> إجمالي الفواتير المصدرة:
                  </span>
                  <span className="font-medium">{totalInvoiced.toLocaleString()} ﷼</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span className="text-muted-foreground flex items-center gap-1">
                    <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" /> إجمالي المحصل:
                  </span>
                  <span className="font-medium text-emerald-600">{totalPaid.toLocaleString()} ﷼</span>
                </div>
                <div className="flex justify-between items-center text-sm pt-2 border-t">
                  <span className="font-medium flex items-center gap-1">
                    <Clock className="h-3.5 w-3.5" /> المتبقي غير محصل:
                  </span>
                  <span className={`font-bold ${totalRemaining > 0 ? 'text-destructive' : 'text-emerald-600'}`}>
                    {totalRemaining.toLocaleString()} ﷼
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-sm bg-card h-fit">
            <CardHeader className="pb-3 border-b">
              <CardTitle>المدة الزمنية</CardTitle>
            </CardHeader>
            <CardContent className="pt-4 space-y-4">
              <div className="flex items-center gap-3">
                <div className="h-10 w-1 bg-emerald-500 rounded-full"></div>
                <div>
                  <p className="text-xs text-muted-foreground mb-0.5">تاريخ البداية</p>
                  <p className="font-medium">{contract.startDate}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="h-10 w-1 bg-destructive rounded-full"></div>
                <div>
                  <p className="text-xs text-muted-foreground mb-0.5">تاريخ النهاية</p>
                  <p className="font-medium">{contract.endDate}</p>
                </div>
              </div>
              
              {contract.status === 'قارب على الانتهاء' && (
                <div className="mt-4 bg-amber-500/10 border border-amber-200 rounded-lg p-3 flex items-start gap-2 text-amber-700">
                  <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
                  <p className="text-xs leading-relaxed">هذا العقد يوشك على الانتهاء. يرجى التواصل مع المستأجر بخصوص التجديد أو الإخلاء.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}