import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Search, Filter, MoreHorizontal, Eye, Edit, Trash, FileText } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAppStore } from "@/store";
import { Contract } from "@/types";
import { useToast } from "@/hooks/use-toast";

export default function ContractsList() {
  const { contracts, tenants, units, properties, addContract, updateContract, cancelContract } = useAppStore();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const [isAddOpen, setIsAddOpen] = useState(false);
  const [formData, setFormData] = useState<Partial<Contract>>({ status: 'ساري', paymentType: 'سنوي' });

  const getTenantName = (tenantId: string) => tenants.find(t => t.id === tenantId)?.name || 'غير معروف';
  const getUnitName = (unitId: string) => {
    const unit = units.find(u => u.id === unitId);
    if (!unit) return { unitName: 'غير معروف', propertyName: 'غير معروف' };
    const property = properties.find(p => p.id === unit.propertyId);
    return { unitName: unit.number, propertyName: property?.name || 'غير معروف' };
  };

  const handleSave = () => {
    if (!formData.tenantId || !formData.unitId || !formData.startDate || !formData.endDate || !formData.amount) {
      toast({ title: "خطأ", description: "الرجاء تعبئة جميع الحقول الأساسية", variant: "destructive" });
      return;
    }
    
    // Check if unit already has an active contract
    const existingContract = contracts.find(c => c.unitId === formData.unitId && (c.status === 'ساري' || c.status === 'قارب على الانتهاء'));
    if (existingContract) {
      toast({ title: "خطأ", description: "الوحدة المحددة مرتبطة بعقد ساري حالياً", variant: "destructive" });
      return;
    }
    
    addContract(formData as Omit<Contract, 'id'>);
    toast({ title: "نجاح", description: "تم إنشاء العقد بنجاح وتم تحديث حالة الوحدة إلى مؤجرة" });
    setIsAddOpen(false);
    setFormData({ status: 'ساري', paymentType: 'سنوي' });
  };

  const handleCancel = (id: string) => {
    if(confirm("هل أنت متأكد من إنهاء هذا العقد مبكراً؟ سيتم تحديث حالة الوحدة إلى شاغرة.")) {
      cancelContract(id);
      toast({ title: "تم الإنهاء", description: "تم إنهاء العقد وتحديث حالة الوحدة بنجاح" });
    }
  };

  // Helper to pre-fill amount from unit's estimated price
  const handleUnitChange = (unitId: string) => {
    const unit = units.find(u => u.id === unitId);
    if (unit) {
      setFormData({ ...formData, unitId, amount: unit.estimatedPrice });
    } else {
      setFormData({ ...formData, unitId });
    }
  };

  const stats = {
    total: contracts.length,
    active: contracts.filter(c => c.status === 'ساري' || c.status === 'قارب على الانتهاء').length,
    expiring: contracts.filter(c => c.status === 'قارب على الانتهاء').length,
    expired: contracts.filter(c => c.status === 'منتهي').length,
    totalValue: contracts.reduce((sum, c) => sum + c.amount, 0),
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground">العقود الإيجارية</h1>
          <p className="text-muted-foreground mt-1">إدارة عقود الإيجار، تجديدها، وإلغائها</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="bg-background">
            <FileText className="mr-2 h-4 w-4" />
            تصدير تقرير
          </Button>
          
          <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
            <DialogTrigger asChild>
              <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
                <Plus className="mr-2 h-4 w-4" />
                إنشاء عقد جديد
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>إنشاء عقد إيجار جديد</DialogTitle>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="tenantId">المستأجر</Label>
                    <Select value={formData.tenantId} onValueChange={(val) => setFormData({...formData, tenantId: val})}>
                      <SelectTrigger>
                        <SelectValue placeholder="اختر المستأجر" />
                      </SelectTrigger>
                      <SelectContent>
                        {tenants.map(tenant => (
                          <SelectItem key={tenant.id} value={tenant.id}>{tenant.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="unitId">الوحدة العقارية (الشاغرة فقط)</Label>
                    <Select value={formData.unitId} onValueChange={handleUnitChange}>
                      <SelectTrigger>
                        <SelectValue placeholder="اختر الوحدة" />
                      </SelectTrigger>
                      <SelectContent>
                        {units.filter(u => u.status === 'شاغرة').map(unit => (
                          <SelectItem key={unit.id} value={unit.id}>
                            {unit.number} - {properties.find(p => p.id === unit.propertyId)?.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="startDate">تاريخ بداية العقد</Label>
                    <Input id="startDate" type="date" value={formData.startDate || ''} onChange={e => setFormData({...formData, startDate: e.target.value})} />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="endDate">تاريخ نهاية العقد</Label>
                    <Input id="endDate" type="date" value={formData.endDate || ''} onChange={e => setFormData({...formData, endDate: e.target.value})} />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="amount">القيمة الإيجارية السنوية</Label>
                    <div className="relative">
                      <Input id="amount" type="number" value={formData.amount || ''} onChange={e => setFormData({...formData, amount: parseInt(e.target.value) || 0})} className="pl-12" />
                      <div className="absolute left-3 top-2.5 text-muted-foreground text-sm">﷼</div>
                    </div>
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="paymentType">طريقة الدفع</Label>
                    <Select value={formData.paymentType} onValueChange={(val: any) => setFormData({...formData, paymentType: val})}>
                      <SelectTrigger>
                        <SelectValue placeholder="اختر الدفعات" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="سنوي">سنوي (دفعة واحدة)</SelectItem>
                        <SelectItem value="نصف سنوي">نصف سنوي (دفعتين)</SelectItem>
                        <SelectItem value="ربع سنوي">ربع سنوي (4 دفعات)</SelectItem>
                        <SelectItem value="شهري">شهري (12 دفعة)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddOpen(false)}>إلغاء</Button>
                <Button onClick={handleSave}>اعتماد العقد وإصدار الفاتورة</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="border-none shadow-sm bg-card">
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground mb-1">العقود السارية</p>
            <p className="text-2xl font-bold text-emerald-500">{stats.active}</p>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm bg-card">
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground mb-1">تنتهي قريباً</p>
            <p className="text-2xl font-bold text-amber-500">{stats.expiring}</p>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm bg-card">
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground mb-1">عقود منتهية أو ملغاة</p>
            <p className="text-2xl font-bold text-destructive">{stats.total - stats.active}</p>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm bg-card">
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground mb-1">إجمالي القيمة السنوية</p>
            <p className="text-2xl font-bold">{stats.totalValue.toLocaleString()} ﷼</p>
          </CardContent>
        </Card>
      </div>

      <Card className="border-none shadow-sm">
        <CardHeader className="pb-3 border-b">
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
            <div className="relative w-full sm:w-96">
              <Search className="absolute right-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="البحث برقم العقد، المستأجر، الوحدة..."
                className="pr-9 bg-muted/50 border-none"
              />
            </div>
            <div className="flex gap-2 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0">
              <Button variant="secondary" size="sm" className="whitespace-nowrap">الكل</Button>
              <Button variant="ghost" size="sm" className="whitespace-nowrap text-muted-foreground">ساري</Button>
              <Button variant="ghost" size="sm" className="whitespace-nowrap text-muted-foreground">قارب على الانتهاء</Button>
              <Button variant="ghost" size="sm" className="whitespace-nowrap text-muted-foreground">منتهي</Button>
              <Button variant="outline" size="icon" className="ml-auto sm:ml-2">
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-right">
              <thead className="bg-muted/30">
                <tr className="border-b">
                  <th className="px-4 py-3 font-medium text-muted-foreground">رقم العقد</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">المستأجر</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">العقار / الوحدة</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">المدة</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">القيمة السنوية</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">الدفعات</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">الحالة</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground w-[80px]">إجراءات</th>
                </tr>
              </thead>
              <tbody>
                {contracts.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="text-center py-8 text-muted-foreground">لا توجد عقود مسجلة</td>
                  </tr>
                ) : contracts.map((contract) => {
                  let statusColor = "bg-muted text-muted-foreground";
                  if (contract.status === "ساري") statusColor = "bg-emerald-500/10 text-emerald-500";
                  else if (contract.status === "قارب على الانتهاء") statusColor = "bg-amber-500/10 text-amber-500";
                  else if (contract.status === "ملغي") statusColor = "bg-destructive/10 text-destructive";

                  const { unitName, propertyName } = getUnitName(contract.unitId);

                  return (
                    <tr 
                      key={contract.id} 
                      className={`border-b last:border-0 hover:bg-muted/20 transition-colors cursor-pointer ${contract.status === 'ملغي' ? 'opacity-60' : ''}`}
                      onClick={() => setLocation(`/contracts/${contract.id}`)}
                    >
                      <td className="px-4 py-3 font-medium text-primary">{contract.id}</td>
                      <td className="px-4 py-3 font-medium">{getTenantName(contract.tenantId)}</td>
                      <td className="px-4 py-3">
                        <div className="flex flex-col">
                          <span className="font-medium">{unitName}</span>
                          <span className="text-xs text-muted-foreground">{propertyName}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex flex-col">
                          <span className="text-xs text-muted-foreground">من: {contract.startDate}</span>
                          <span className="text-xs text-muted-foreground">إلى: {contract.endDate}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 font-medium">{contract.amount.toLocaleString()} ﷼</td>
                      <td className="px-4 py-3 text-muted-foreground">{contract.paymentType}</td>
                      <td className="px-4 py-3">
                        <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${statusColor}`}>
                          {contract.status}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <span className="sr-only">فتح القائمة</span>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem className="cursor-pointer">
                              <Eye className="mr-2 h-4 w-4" />
                              <span>عرض العقد</span>
                            </DropdownMenuItem>
                            <DropdownMenuItem className="cursor-pointer">
                              <FileText className="mr-2 h-4 w-4" />
                              <span>طباعة PDF</span>
                            </DropdownMenuItem>
                            {(contract.status === 'ساري' || contract.status === 'قارب على الانتهاء') && (
                              <>
                                <DropdownMenuItem className="cursor-pointer">
                                  <Edit className="mr-2 h-4 w-4" />
                                  <span>تجديد العقد</span>
                                </DropdownMenuItem>
                                <DropdownMenuItem className="cursor-pointer text-destructive" onClick={() => handleCancel(contract.id)}>
                                  <Trash className="mr-2 h-4 w-4" />
                                  <span>إنهاء مبكر (إخلاء)</span>
                                </DropdownMenuItem>
                              </>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}