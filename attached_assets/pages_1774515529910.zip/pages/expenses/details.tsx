import { useParams, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Calculator, Building2, Calendar, User, FileText, CheckCircle2 } from "lucide-react";
import { useAppStore } from "@/store";

export default function ExpenseDetails() {
  const { id } = useParams();
  const { expenses, properties } = useAppStore();
  
  const expense = expenses.find(e => e.id === id);
  
  if (!expense) {
    return (
      <div className="flex flex-col items-center justify-center h-full space-y-4">
        <h2 className="text-2xl font-bold">المصروف غير موجود</h2>
        <Link href="/expenses"><Button variant="outline">العودة لقائمة المصروفات</Button></Link>
      </div>
    );
  }

  const property = expense.propertyId && expense.propertyId !== 'عام' 
    ? properties.find(p => p.id === expense.propertyId) 
    : null;

  let statusColor = "bg-muted text-muted-foreground";
  if (expense.status === "مدفوع") statusColor = "bg-emerald-500/10 text-emerald-500 border-emerald-200";
  else if (expense.status === "معتمد") statusColor = "bg-blue-500/10 text-blue-500 border-blue-200";
  else if (expense.status === "قيد الاعتماد") statusColor = "bg-amber-500/10 text-amber-500 border-amber-200";
  else if (expense.status === "ملغي") statusColor = "bg-destructive/10 text-destructive border-destructive/20 line-through";

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-4">
          <Link href="/expenses">
            <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
              <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-display font-bold text-foreground">مصروف رقم: {expense.id}</h1>
            <div className="flex items-center gap-2 mt-1">
              <Badge variant="outline" className={`font-normal ${statusColor}`}>
                {expense.status}
              </Badge>
              <span className="text-muted-foreground text-sm">•</span>
              <span className="text-muted-foreground text-sm">التصنيف: {expense.category}</span>
            </div>
          </div>
        </div>
        <div className="flex gap-2">
          {expense.status === 'قيد الاعتماد' && (
            <Button className="bg-primary text-primary-foreground">اعتماد المصروف</Button>
          )}
          {expense.status === 'معتمد' && (
            <Button className="bg-emerald-600 hover:bg-emerald-700 text-white">تسجيل الدفع</Button>
          )}
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-6">
          <Card className="border-none shadow-sm">
            <CardHeader className="pb-3 border-b">
              <CardTitle>تفاصيل المصروف</CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="mb-8 p-6 bg-muted/20 rounded-xl border border-border/50 text-center">
                <p className="text-sm font-medium text-muted-foreground mb-2">قيمة المصروف</p>
                <h2 className="text-5xl font-bold text-foreground mb-1" style={{ fontFamily: 'monospace' }}>
                  {expense.amount.toLocaleString()} <span className="text-2xl text-muted-foreground">﷼</span>
                </h2>
              </div>
              
              <div className="space-y-6">
                <div>
                  <h4 className="text-sm font-semibold text-muted-foreground mb-2 flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    البيان / الوصف
                  </h4>
                  <p className="text-lg font-medium">{expense.description}</p>
                </div>
                
                <div className="grid sm:grid-cols-2 gap-6 pt-4 border-t border-border/50">
                  <div>
                    <h4 className="text-sm font-semibold text-muted-foreground mb-2 flex items-center gap-2">
                      <User className="h-4 w-4" />
                      المستفيد / المورد
                    </h4>
                    <p className="font-medium">{expense.vendor}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-muted-foreground mb-2 flex items-center gap-2">
                      <Calendar className="h-4 w-4" />
                      تاريخ المصروف
                    </h4>
                    <p className="font-medium" dir="ltr">{expense.date}</p>
                  </div>
                </div>

                <div className="pt-4 border-t border-border/50">
                  <h4 className="text-sm font-semibold text-muted-foreground mb-2 flex items-center gap-2">
                    <Building2 className="h-4 w-4" />
                    الارتباط (مركز التكلفة)
                  </h4>
                  {property ? (
                    <Link href={`/properties/${property.id}`} className="font-medium text-primary hover:underline flex items-center gap-2">
                      {property.name}
                      <span className="text-xs bg-muted text-muted-foreground px-2 py-0.5 rounded-full no-underline">
                        {property.type}
                      </span>
                    </Link>
                  ) : (
                    <span className="font-medium text-foreground bg-secondary px-3 py-1 rounded-full text-sm">مصروف عام (مصاريف تشغيلية)</span>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="border-none shadow-sm bg-card h-fit">
            <CardHeader className="pb-3 border-b">
              <CardTitle>مراحل الاعتماد والدفع</CardTitle>
            </CardHeader>
            <CardContent className="pt-6 space-y-6">
              <div className="relative border-r-2 border-muted pr-4 mr-2 space-y-6">
                
                <div className="relative">
                  <div className="absolute -right-[23px] top-0 h-4 w-4 rounded-full bg-emerald-500 ring-4 ring-background"></div>
                  <div>
                    <p className="font-bold text-sm">تسجيل المصروف</p>
                    <p className="text-xs text-muted-foreground mt-1">تم التسجيل بواسطة النظام</p>
                  </div>
                </div>

                <div className="relative">
                  <div className={`absolute -right-[23px] top-0 h-4 w-4 rounded-full ring-4 ring-background ${expense.status === 'معتمد' || expense.status === 'مدفوع' ? 'bg-emerald-500' : expense.status === 'قيد الاعتماد' ? 'bg-amber-500' : 'bg-muted'}`}></div>
                  <div>
                    <p className={`font-bold text-sm ${expense.status === 'قيد الاعتماد' ? 'text-amber-600' : expense.status === 'ملغي' ? 'text-muted-foreground' : ''}`}>اعتماد الإدارة</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {expense.status === 'قيد الاعتماد' ? 'في انتظار المراجعة' : expense.status === 'ملغي' ? 'ملغي' : 'تم الاعتماد'}
                    </p>
                  </div>
                </div>

                <div className="relative">
                  <div className={`absolute -right-[23px] top-0 h-4 w-4 rounded-full ring-4 ring-background ${expense.status === 'مدفوع' ? 'bg-emerald-500' : 'bg-muted'}`}></div>
                  <div>
                    <p className={`font-bold text-sm ${expense.status === 'معتمد' ? 'text-amber-600' : expense.status === 'ملغي' ? 'text-muted-foreground' : ''}`}>سداد المورد</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {expense.status === 'مدفوع' ? 'تم تحويل المبلغ' : 'في انتظار الدفع'}
                    </p>
                  </div>
                </div>

              </div>
              
              {expense.status === 'مدفوع' && (
                <div className="mt-6 bg-emerald-50 border border-emerald-200 rounded-lg p-3 flex items-center justify-center gap-2 text-emerald-700">
                  <CheckCircle2 className="h-5 w-5" />
                  <span className="font-bold text-sm">اكتملت دورة المصروف</span>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}