import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Search, Filter, MoreHorizontal, Eye, Edit, Trash, Download, Calculator } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAppStore } from "@/store";
import { Expense } from "@/types";
import { useToast } from "@/hooks/use-toast";

export default function ExpensesList() {
  const { expenses, properties, addExpense, updateExpense, cancelExpense } = useAppStore();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const [isAddOpen, setIsAddOpen] = useState(false);
  const [formData, setFormData] = useState<Partial<Expense>>({ status: 'قيد الاعتماد', category: 'صيانة عامة' });

  const getPropertyName = (propertyId?: string) => {
    if (!propertyId || propertyId === 'عام') return 'عام';
    return properties.find(p => p.id === propertyId)?.name || 'غير معروف';
  };

  const handleSave = () => {
    if (!formData.category || !formData.description || !formData.amount || !formData.vendor) {
      toast({ title: "خطأ", description: "الرجاء تعبئة الحقول الأساسية", variant: "destructive" });
      return;
    }
    
    // Set current date if not provided
    const newExpense = {
      ...formData,
      date: formData.date || new Date().toISOString().split('T')[0],
      propertyId: formData.propertyId === 'عام' ? undefined : formData.propertyId
    };
    
    addExpense(newExpense as Omit<Expense, 'id'>);
    toast({ title: "نجاح", description: "تم تسجيل المصروف بنجاح" });
    setIsAddOpen(false);
    setFormData({ status: 'قيد الاعتماد', category: 'صيانة عامة' });
  };

  const handleCancel = (id: string) => {
    if(confirm("هل أنت متأكد من إلغاء هذا المصروف؟")) {
      cancelExpense(id);
      toast({ title: "تم الإلغاء", description: "تم إلغاء المصروف بنجاح" });
    }
  };

  const stats = {
    total: expenses.filter(e => e.status !== 'ملغي').reduce((sum, e) => sum + e.amount, 0),
    maintenance: expenses.filter(e => e.status !== 'ملغي' && (e.category === 'صيانة عامة' || e.category === 'نظافة')).reduce((sum, e) => sum + e.amount, 0),
    utilities: expenses.filter(e => e.status !== 'ملغي' && e.category === 'فواتير خدمات').reduce((sum, e) => sum + e.amount, 0),
    pending: expenses.filter(e => e.status === 'قيد الاعتماد').reduce((sum, e) => sum + e.amount, 0),
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground">المصروفات</h1>
          <p className="text-muted-foreground mt-1">إدارة وتسجيل النفقات والفواتير</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="bg-background">
            <Download className="mr-2 h-4 w-4" />
            تصدير تقرير
          </Button>

          <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
            <DialogTrigger asChild>
              <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
                <Plus className="mr-2 h-4 w-4" />
                إضافة مصروف جديد
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>تسجيل مصروف جديد</DialogTitle>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="propertyId">العقار المرتبط (اختياري)</Label>
                  <Select value={formData.propertyId || 'عام'} onValueChange={(val) => setFormData({...formData, propertyId: val})}>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر العقار أو مصروف عام" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="عام">مصروف عام (غير مرتبط بعقار)</SelectItem>
                      {properties.map(property => (
                        <SelectItem key={property.id} value={property.id}>{property.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="category">التصنيف</Label>
                    <Select value={formData.category} onValueChange={(val) => setFormData({...formData, category: val})}>
                      <SelectTrigger>
                        <SelectValue placeholder="اختر التصنيف" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="صيانة عامة">صيانة عامة</SelectItem>
                        <SelectItem value="فواتير خدمات">فواتير خدمات</SelectItem>
                        <SelectItem value="نظافة">نظافة</SelectItem>
                        <SelectItem value="مصاريف إدارية">مصاريف إدارية</SelectItem>
                        <SelectItem value="رواتب وأجور">رواتب وأجور</SelectItem>
                        <SelectItem value="أخرى">أخرى</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="date">التاريخ</Label>
                    <Input id="date" type="date" value={formData.date || ''} onChange={e => setFormData({...formData, date: e.target.value})} />
                  </div>
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="description">البيان / الوصف</Label>
                  <Input id="description" value={formData.description || ''} onChange={e => setFormData({...formData, description: e.target.value})} placeholder="وصف المصروف..." />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="amount">المبلغ</Label>
                    <div className="relative">
                      <Input id="amount" type="number" value={formData.amount || ''} onChange={e => setFormData({...formData, amount: parseInt(e.target.value) || 0})} className="pl-12" />
                      <div className="absolute left-3 top-2.5 text-muted-foreground text-sm">﷼</div>
                    </div>
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="vendor">المورد / المستفيد</Label>
                    <Input id="vendor" value={formData.vendor || ''} onChange={e => setFormData({...formData, vendor: e.target.value})} placeholder="اسم الجهة المستفيدة" />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddOpen(false)}>إلغاء</Button>
                <Button onClick={handleSave}>حفظ المصروف</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="border-none shadow-sm bg-card">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">إجمالي المصروفات</p>
              <p className="text-2xl font-bold">{stats.total.toLocaleString()} ﷼</p>
            </div>
            <div className="p-2 bg-destructive/10 rounded-lg">
              <Calculator className="h-5 w-5 text-destructive" />
            </div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm bg-card">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">صيانة وتشغيل</p>
              <p className="text-2xl font-bold">{stats.maintenance.toLocaleString()} ﷼</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm bg-card">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">فواتير خدمات</p>
              <p className="text-2xl font-bold">{stats.utilities.toLocaleString()} ﷼</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm bg-card">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">قيد الاعتماد</p>
              <p className="text-2xl font-bold text-amber-500">{stats.pending.toLocaleString()} ﷼</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-none shadow-sm">
        <CardHeader className="pb-3 border-b">
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
            <div className="relative w-full sm:w-96">
              <Search className="absolute right-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="البحث برقم المصروف، الوصف، أو المورد..."
                className="pr-9 bg-muted/50 border-none"
              />
            </div>
            <div className="flex gap-2 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0">
              <Button variant="secondary" size="sm" className="whitespace-nowrap">الكل</Button>
              <Button variant="ghost" size="sm" className="whitespace-nowrap text-muted-foreground">صيانة</Button>
              <Button variant="ghost" size="sm" className="whitespace-nowrap text-muted-foreground">خدمات</Button>
              <Button variant="ghost" size="sm" className="whitespace-nowrap text-muted-foreground">رواتب</Button>
              <Button variant="outline" size="icon" className="ml-auto sm:ml-2">
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-right">
              <thead className="bg-muted/30">
                <tr className="border-b">
                  <th className="px-4 py-3 font-medium text-muted-foreground">رقم المصروف</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">العقار / المشروع</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">التصنيف</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">البيان</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">المورد / المستفيد</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">التاريخ</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">المبلغ</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">الحالة</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground w-[80px]">إجراءات</th>
                </tr>
              </thead>
              <tbody>
                {expenses.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="text-center py-8 text-muted-foreground">لا توجد مصروفات مسجلة</td>
                  </tr>
                ) : expenses.map((expense) => {
                  let statusColor = "bg-muted text-muted-foreground";
                  if (expense.status === "مدفوع") statusColor = "bg-emerald-500/10 text-emerald-500";
                  else if (expense.status === "معتمد") statusColor = "bg-blue-500/10 text-blue-500";
                  else if (expense.status === "قيد الاعتماد") statusColor = "bg-amber-500/10 text-amber-500";
                  else if (expense.status === "ملغي") statusColor = "bg-muted text-muted-foreground line-through";

                  return (
                    <tr 
                      key={expense.id} 
                      className={`border-b last:border-0 hover:bg-muted/20 transition-colors cursor-pointer ${expense.status === 'ملغي' ? 'opacity-50' : ''}`}
                      onClick={() => setLocation(`/expenses/${expense.id}`)}
                    >
                      <td className="px-4 py-3 font-medium text-primary">{expense.id}</td>
                      <td className="px-4 py-3">{getPropertyName(expense.propertyId)}</td>
                      <td className="px-4 py-3 text-muted-foreground">{expense.category}</td>
                      <td className="px-4 py-3">{expense.description}</td>
                      <td className="px-4 py-3 text-muted-foreground">{expense.vendor}</td>
                      <td className="px-4 py-3 text-muted-foreground">{expense.date}</td>
                      <td className="px-4 py-3 font-bold">{expense.amount.toLocaleString()} ﷼</td>
                      <td className="px-4 py-3">
                        <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${statusColor}`}>
                          {expense.status}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <span className="sr-only">فتح القائمة</span>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem className="cursor-pointer">
                              <Eye className="mr-2 h-4 w-4" />
                              <span>عرض التفاصيل</span>
                            </DropdownMenuItem>
                            {expense.status !== 'ملغي' && (
                              <DropdownMenuItem className="cursor-pointer">
                                <Edit className="mr-2 h-4 w-4" />
                                <span>تعديل</span>
                              </DropdownMenuItem>
                            )}
                            {expense.status !== 'مدفوع' && expense.status !== 'ملغي' && (
                              <DropdownMenuItem className="cursor-pointer text-destructive" onClick={() => handleCancel(expense.id)}>
                                <Trash className="mr-2 h-4 w-4" />
                                <span>إلغاء</span>
                              </DropdownMenuItem>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}