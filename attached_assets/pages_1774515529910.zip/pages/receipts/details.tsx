import { useParams, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Printer, Download, CreditCard, Building2, Calendar, FileText, CheckCircle2 } from "lucide-react";
import { useAppStore } from "@/store";

export default function ReceiptDetails() {
  const { id } = useParams();
  const { receipts, invoices, tenants, contracts, units, properties } = useAppStore();
  
  const receipt = receipts.find(r => r.id === id);
  
  if (!receipt) {
    return (
      <div className="flex flex-col items-center justify-center h-full space-y-4">
        <h2 className="text-2xl font-bold">سند القبض غير موجود</h2>
        <Link href="/receipts"><Button variant="outline">العودة لقائمة السندات</Button></Link>
      </div>
    );
  }

  const tenant = tenants.find(t => t.id === receipt.tenantId);
  const invoice = receipt.invoiceId ? invoices.find(i => i.id === receipt.invoiceId) : null;
  const contract = invoice ? contracts.find(c => c.id === invoice.contractId) : null;
  const unit = contract ? units.find(u => u.id === contract.unitId) : null;
  const property = unit ? properties.find(p => p.id === unit.propertyId) : null;

  let statusColor = "bg-muted text-muted-foreground";
  if (receipt.status === "مكتمل") statusColor = "bg-emerald-500/10 text-emerald-500 border-emerald-200";
  else if (receipt.status === "قيد المعالجة") statusColor = "bg-amber-500/10 text-amber-500 border-amber-200";
  else if (receipt.status === "ملغي") statusColor = "bg-destructive/10 text-destructive border-destructive/20 line-through";

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-4">
          <Link href="/receipts">
            <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
              <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-display font-bold text-foreground">سند قبض رقم: {receipt.id}</h1>
            <div className="flex items-center gap-2 mt-1">
              <Badge variant="outline" className={`font-normal ${statusColor}`}>
                {receipt.status}
              </Badge>
              <span className="text-muted-foreground text-sm">•</span>
              <span className="text-muted-foreground text-sm">تاريخ السند: {receipt.date}</span>
            </div>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="bg-background">
            <Printer className="mr-2 h-4 w-4" />
            طباعة السند
          </Button>
          <Button variant="outline" className="bg-background">
            <Download className="mr-2 h-4 w-4" />
            تحميل PDF
          </Button>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-6">
          <Card className="border-none shadow-sm overflow-hidden">
            <div className="bg-primary/5 p-8 border-b text-center relative">
              <div className="absolute top-4 right-4 opacity-10">
                <CreditCard className="w-32 h-32" />
              </div>
              <p className="text-sm font-medium text-muted-foreground mb-2">المبلغ الإجمالي المحصل</p>
              <h2 className="text-5xl font-bold text-primary mb-2" style={{ fontFamily: 'monospace' }}>
                {receipt.amount.toLocaleString()} <span className="text-2xl text-foreground">﷼</span>
              </h2>
              <p className="text-sm text-muted-foreground bg-background/50 inline-block px-4 py-1 rounded-full border border-border/50">
                طريقة الدفع: {receipt.method} {receipt.reference && `(${receipt.reference})`}
              </p>
            </div>
            
            <CardContent className="p-6">
              <div className="grid sm:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">استلمنا من المكرم / السادة:</p>
                    {tenant ? (
                      <Link href={`/tenants/${tenant.id}`} className="font-bold text-lg hover:underline block">
                        {tenant.name}
                      </Link>
                    ) : (
                      <span className="font-medium">غير معروف</span>
                    )}
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">وذلك عن الفاتورة / العقد:</p>
                    {invoice ? (
                      <Link href={`/invoices/${invoice.id}`} className="font-medium text-primary hover:underline block">
                        فاتورة رقم {invoice.id}
                      </Link>
                    ) : (
                      <span className="text-sm">دفعة مقدمة / غير محدد</span>
                    )}
                  </div>
                </div>

                <div className="space-y-4 md:text-left">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">العين المؤجرة:</p>
                    {unit && property ? (
                      <div>
                        <Link href={`/units/${unit.id}`} className="font-medium hover:underline block">
                          {unit.number} ({unit.type})
                        </Link>
                        <Link href={`/properties/${property.id}`} className="text-sm text-muted-foreground hover:underline">
                          {property.name}
                        </Link>
                      </div>
                    ) : (
                      <span className="text-sm text-muted-foreground">غير محدد</span>
                    )}
                  </div>
                  {receipt.status === 'مكتمل' && (
                    <div className="inline-flex items-center gap-2 bg-emerald-50 text-emerald-700 px-3 py-1.5 rounded-lg text-sm font-medium border border-emerald-200 md:ml-auto">
                      <CheckCircle2 className="h-4 w-4" />
                      التحصيل مكتمل
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="border-none shadow-sm bg-card">
            <CardHeader className="pb-3 border-b">
              <CardTitle>معلومات الفاتورة المرتبطة</CardTitle>
            </CardHeader>
            <CardContent className="pt-4 space-y-4">
              {invoice ? (
                <>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-muted-foreground">قيمة الفاتورة الأصلية:</span>
                    <span className="font-bold">{invoice.amount.toLocaleString()} ﷼</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-muted-foreground">إجمالي المحصل:</span>
                    <span className="font-bold text-emerald-600">{invoice.paid.toLocaleString()} ﷼</span>
                  </div>
                  <div className="flex justify-between items-center text-sm pt-2 border-t">
                    <span className="text-muted-foreground">حالة الفاتورة الآن:</span>
                    <Badge variant="outline" className="bg-muted">
                      {invoice.status}
                    </Badge>
                  </div>
                  
                  <div className="pt-4 text-center">
                    <Link href={`/invoices/${invoice.id}`}>
                      <Button variant="outline" className="w-full">عرض الفاتورة كاملة</Button>
                    </Link>
                  </div>
                </>
              ) : (
                <div className="text-center py-6 text-muted-foreground">
                  <FileText className="h-10 w-10 mx-auto mb-2 opacity-30" />
                  <p className="text-sm">هذا السند غير مرتبط بفاتورة محددة (دفعة مقدمة).</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}