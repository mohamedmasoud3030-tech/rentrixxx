import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Search, Filter, MoreHorizontal, Eye, Edit, Trash, FileText, CheckCircle2, FileSpreadsheet } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAppStore } from "@/store";
import { Receipt } from "@/types";
import { useToast } from "@/hooks/use-toast";

export default function ReceiptsList() {
  const { receipts, invoices, tenants, addReceipt, cancelReceipt } = useAppStore();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const [isAddOpen, setIsAddOpen] = useState(false);
  const [formData, setFormData] = useState<Partial<Receipt>>({ status: 'مكتمل', method: 'حوالة بنكية', amount: 0 });

  const getDetails = (invoiceId?: string, tenantId?: string) => {
    const invoice = invoices.find(i => i.id === invoiceId);
    const tenant = tenants.find(t => t.id === tenantId);
    return {
      invoiceName: invoice ? invoice.id : 'غير محدد',
      tenantName: tenant ? tenant.name : 'غير معروف'
    };
  };

  const handleSave = () => {
    if (!formData.tenantId || !formData.amount || !formData.method) {
      toast({ title: "خطأ", description: "الرجاء تعبئة الحقول الأساسية", variant: "destructive" });
      return;
    }
    
    // Set current date if not provided
    const newReceipt = {
      ...formData,
      date: formData.date || new Date().toISOString().split('T')[0],
    };
    
    addReceipt(newReceipt as Omit<Receipt, 'id'>);
    toast({ title: "نجاح", description: "تم إصدار سند القبض بنجاح" });
    setIsAddOpen(false);
    setFormData({ status: 'مكتمل', method: 'حوالة بنكية', amount: 0 });
  };

  const handleCancel = (id: string) => {
    if(confirm("هل أنت متأكد من إلغاء سند القبض؟ سيتم خصم المبلغ من الفاتورة المرتبطة.")) {
      cancelReceipt(id);
      toast({ title: "تم الإلغاء", description: "تم إلغاء السند وتحديث الفاتورة بنجاح" });
    }
  };

  // Helper to pre-fill tenant based on selected invoice
  const handleInvoiceChange = (invoiceId: string) => {
    if (invoiceId === '-') {
      setFormData({ ...formData, invoiceId: undefined });
      return;
    }
    const invoice = invoices.find(i => i.id === invoiceId);
    if (invoice) {
      const remainingAmount = invoice.amount - invoice.paid;
      setFormData({ ...formData, invoiceId, tenantId: invoice.tenantId, amount: remainingAmount > 0 ? remainingAmount : 0 });
    } else {
      setFormData({ ...formData, invoiceId });
    }
  };

  const stats = {
    total: receipts.filter(r => r.status !== 'ملغي').reduce((sum, r) => sum + r.amount, 0),
    transfers: receipts.filter(r => r.status !== 'ملغي' && r.method === 'حوالة بنكية').reduce((sum, r) => sum + r.amount, 0),
    cash: receipts.filter(r => r.status !== 'ملغي' && r.method === 'نقدي').reduce((sum, r) => sum + r.amount, 0),
    sadad: receipts.filter(r => r.status !== 'ملغي' && r.method === 'مدفوعات سداد').reduce((sum, r) => sum + r.amount, 0),
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground">سندات القبض</h1>
          <p className="text-muted-foreground mt-1">إدارة التحصيلات والمدفوعات المستلمة</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="bg-background">
            <FileSpreadsheet className="mr-2 h-4 w-4" />
            تصدير كشف حساب
          </Button>
          
          <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
            <DialogTrigger asChild>
              <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
                <Plus className="mr-2 h-4 w-4" />
                إصدار سند قبض
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>إصدار سند قبض جديد</DialogTitle>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="invoiceId">الفاتورة المرتبطة (اختياري)</Label>
                  <Select value={formData.invoiceId || '-'} onValueChange={handleInvoiceChange}>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر الفاتورة" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="-">بدون ارتباط بفاتورة (دفعة مقدمة)</SelectItem>
                      {invoices.filter(i => i.status !== 'ملغاة' && i.status !== 'مدفوع').map(invoice => {
                        const tenantName = tenants.find(t => t.id === invoice.tenantId)?.name;
                        return (
                          <SelectItem key={invoice.id} value={invoice.id}>
                            {invoice.id} - {tenantName} (متبقي: {invoice.amount - invoice.paid} ﷼)
                          </SelectItem>
                        );
                      })}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="grid gap-2">
                  <Label htmlFor="tenantId">المستأجر / الدافع</Label>
                  <Select 
                    value={formData.tenantId} 
                    onValueChange={(val) => setFormData({...formData, tenantId: val})}
                    disabled={!!formData.invoiceId}
                  >
                    <SelectTrigger className={formData.invoiceId ? "bg-muted" : ""}>
                      <SelectValue placeholder="اختر المستأجر" />
                    </SelectTrigger>
                    <SelectContent>
                      {tenants.map(tenant => (
                        <SelectItem key={tenant.id} value={tenant.id}>{tenant.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="amount">المبلغ المحصل</Label>
                    <div className="relative">
                      <Input id="amount" type="number" value={formData.amount || ''} onChange={e => setFormData({...formData, amount: parseInt(e.target.value) || 0})} className="pl-12" />
                      <div className="absolute left-3 top-2.5 text-muted-foreground text-sm">﷼</div>
                    </div>
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="date">تاريخ التحصيل</Label>
                    <Input id="date" type="date" value={formData.date || ''} onChange={e => setFormData({...formData, date: e.target.value})} />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="method">طريقة الدفع</Label>
                    <Select value={formData.method} onValueChange={(val: any) => setFormData({...formData, method: val})}>
                      <SelectTrigger>
                        <SelectValue placeholder="اختر طريقة الدفع" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="حوالة بنكية">حوالة بنكية</SelectItem>
                        <SelectItem value="نقدي">نقدي</SelectItem>
                        <SelectItem value="شيك">شيك</SelectItem>
                        <SelectItem value="نقاط بيع">نقاط بيع (POS)</SelectItem>
                        <SelectItem value="مدفوعات سداد">مدفوعات سداد</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="reference">الرقم المرجعي (اختياري)</Label>
                    <Input id="reference" value={formData.reference || ''} onChange={e => setFormData({...formData, reference: e.target.value})} placeholder="رقم الحوالة أو الشيك" />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddOpen(false)}>إلغاء</Button>
                <Button onClick={handleSave}>إصدار السند</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="border-none shadow-sm bg-card">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">إجمالي التحصيلات</p>
              <p className="text-2xl font-bold">{stats.total.toLocaleString()} ﷼</p>
            </div>
            <div className="p-2 bg-emerald-500/10 rounded-lg">
              <CheckCircle2 className="h-5 w-5 text-emerald-500" />
            </div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm bg-card">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">حوالات بنكية</p>
              <p className="text-2xl font-bold">{stats.transfers.toLocaleString()} ﷼</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm bg-card">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">نقدي</p>
              <p className="text-2xl font-bold">{stats.cash.toLocaleString()} ﷼</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm bg-card">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">مدفوعات سداد</p>
              <p className="text-2xl font-bold">{stats.sadad.toLocaleString()} ﷼</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-none shadow-sm">
        <CardHeader className="pb-3 border-b">
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
            <div className="relative w-full sm:w-96">
              <Search className="absolute right-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="البحث برقم السند، المستأجر، الرقم المرجعي..."
                className="pr-9 bg-muted/50 border-none"
              />
            </div>
            <div className="flex gap-2 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0">
              <Button variant="secondary" size="sm" className="whitespace-nowrap">الكل</Button>
              <Button variant="ghost" size="sm" className="whitespace-nowrap text-muted-foreground">حوالة</Button>
              <Button variant="ghost" size="sm" className="whitespace-nowrap text-muted-foreground">نقدي</Button>
              <Button variant="ghost" size="sm" className="whitespace-nowrap text-muted-foreground">شيك</Button>
              <Button variant="outline" size="icon" className="ml-auto sm:ml-2">
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-right">
              <thead className="bg-muted/30">
                <tr className="border-b">
                  <th className="px-4 py-3 font-medium text-muted-foreground">رقم السند</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">المستأجر / الفاتورة</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">التاريخ</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">طريقة الدفع</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">الرقم المرجعي</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">المبلغ</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">الحالة</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground w-[80px]">إجراءات</th>
                </tr>
              </thead>
              <tbody>
                {receipts.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="text-center py-8 text-muted-foreground">لا توجد سندات قبض</td>
                  </tr>
                ) : receipts.map((receipt) => {
                  let statusColor = "bg-muted text-muted-foreground";
                  if (receipt.status === "مكتمل") statusColor = "bg-emerald-500/10 text-emerald-500";
                  else if (receipt.status === "قيد المعالجة") statusColor = "bg-amber-500/10 text-amber-500";
                  else if (receipt.status === "ملغي") statusColor = "bg-muted text-muted-foreground line-through";

                  const details = getDetails(receipt.invoiceId, receipt.tenantId);

                  return (
                    <tr 
                      key={receipt.id} 
                      className={`border-b last:border-0 hover:bg-muted/20 transition-colors cursor-pointer ${receipt.status === 'ملغي' ? 'opacity-50' : ''}`}
                      onClick={() => setLocation(`/receipts/${receipt.id}`)}
                    >
                      <td className="px-4 py-3 font-medium text-primary">{receipt.id}</td>
                      <td className="px-4 py-3">
                        <div className="flex flex-col">
                          <span className="font-medium">{details.tenantName}</span>
                          <span className="text-xs text-muted-foreground">{receipt.invoiceId ? `فاتورة: ${details.invoiceName}` : 'دفعة مقدمة'}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-muted-foreground">{receipt.date}</td>
                      <td className="px-4 py-3">{receipt.method}</td>
                      <td className="px-4 py-3 text-muted-foreground" dir="ltr">{receipt.reference || '-'}</td>
                      <td className="px-4 py-3 font-bold text-emerald-600">{receipt.amount.toLocaleString()} ﷼</td>
                      <td className="px-4 py-3">
                        <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${statusColor}`}>
                          {receipt.status}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <span className="sr-only">فتح القائمة</span>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem className="cursor-pointer">
                              <Eye className="mr-2 h-4 w-4" />
                              <span>عرض السند</span>
                            </DropdownMenuItem>
                            <DropdownMenuItem className="cursor-pointer">
                              <FileText className="mr-2 h-4 w-4" />
                              <span>طباعة PDF</span>
                            </DropdownMenuItem>
                            {receipt.status !== 'ملغي' && (
                              <DropdownMenuItem className="cursor-pointer text-destructive" onClick={() => handleCancel(receipt.id)}>
                                <Trash className="mr-2 h-4 w-4" />
                                <span>إلغاء السند</span>
                              </DropdownMenuItem>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}