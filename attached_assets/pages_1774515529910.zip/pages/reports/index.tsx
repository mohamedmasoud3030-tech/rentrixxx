import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAppStore } from "@/store";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';
import { Download, FileSpreadsheet, Printer, TrendingUp, TrendingDown, Building, Users } from "lucide-react";

const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6'];

export default function ReportsList() {
  const { invoices, expenses, units, contracts } = useAppStore();

  // Calculate monthly income vs expenses for the chart (Mock data logic based on store)
  const monthlyData = [
    { name: 'يناير', الدخل: 45000, المصروفات: 12000 },
    { name: 'فبراير', الدخل: 52000, المصروفات: 8500 },
    { name: 'مارس', الدخل: 38000, المصروفات: 15000 },
    { name: 'أبريل', الدخل: 65000, المصروفات: 9000 },
    { name: 'مايو', الدخل: 48000, المصروفات: 11000 },
    { name: 'يونيو', الدخل: 55000, المصروفات: 7500 },
  ];

  // Occupancy data
  const occupiedCount = units.filter(u => u.status === 'مؤجرة').length;
  const vacantCount = units.filter(u => u.status === 'شاغرة').length;
  const maintenanceCount = units.filter(u => u.status === 'صيانة').length;

  const occupancyData = [
    { name: 'مؤجرة', value: occupiedCount },
    { name: 'شاغرة', value: vacantCount },
    { name: 'تحت الصيانة', value: maintenanceCount },
  ];

  // Financial Stats
  const totalIncome = invoices.filter(i => i.status !== 'ملغاة').reduce((sum, i) => sum + i.paid, 0);
  const totalExpenses = expenses.filter(e => e.status !== 'ملغي').reduce((sum, e) => sum + e.amount, 0);
  const expectedIncome = invoices.filter(i => i.status !== 'ملغاة').reduce((sum, i) => sum + i.amount, 0);
  const collectionRate = expectedIncome > 0 ? Math.round((totalIncome / expectedIncome) * 100) : 0;

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground">التقارير والإحصائيات</h1>
          <p className="text-muted-foreground mt-1">نظرة شاملة على أداء المحافظ العقارية والوضع المالي</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="bg-background">
            <Printer className="mr-2 h-4 w-4" />
            طباعة
          </Button>
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
            <Download className="mr-2 h-4 w-4" />
            تصدير التقرير (PDF)
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-none shadow-sm bg-card">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">إجمالي التحصيلات</p>
              <p className="text-2xl font-bold text-emerald-500">{totalIncome.toLocaleString()} ﷼</p>
            </div>
            <div className="p-3 bg-emerald-500/10 rounded-lg">
              <TrendingUp className="h-5 w-5 text-emerald-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-none shadow-sm bg-card">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">إجمالي المصروفات</p>
              <p className="text-2xl font-bold text-destructive">{totalExpenses.toLocaleString()} ﷼</p>
            </div>
            <div className="p-3 bg-destructive/10 rounded-lg">
              <TrendingDown className="h-5 w-5 text-destructive" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-sm bg-card">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">نسبة التحصيل</p>
              <p className="text-2xl font-bold text-primary">{collectionRate}%</p>
            </div>
            <div className="p-3 bg-primary/10 rounded-lg">
              <FileSpreadsheet className="h-5 w-5 text-primary" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-sm bg-card">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">نسبة الإشغال</p>
              <p className="text-2xl font-bold text-blue-500">
                {units.length > 0 ? Math.round((occupiedCount / units.length) * 100) : 0}%
              </p>
            </div>
            <div className="p-3 bg-blue-500/10 rounded-lg">
              <Building className="h-5 w-5 text-blue-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="financial" className="w-full">
        <TabsList className="w-full justify-start border-b rounded-none h-auto p-0 bg-transparent mb-6">
          <TabsTrigger value="financial" className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-6 py-3">التقارير المالية</TabsTrigger>
          <TabsTrigger value="occupancy" className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-6 py-3">إشغال الوحدات</TabsTrigger>
          <TabsTrigger value="contracts" className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-6 py-3">العقود والمستأجرين</TabsTrigger>
        </TabsList>

        <TabsContent value="financial" className="space-y-6">
          <Card className="border-none shadow-sm">
            <CardHeader>
              <CardTitle>التدفق النقدي (آخر 6 أشهر)</CardTitle>
              <CardDescription>مقارنة بين الإيرادات والمصروفات</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px] w-full" dir="ltr">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={monthlyData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip 
                      contentStyle={{ textAlign: 'right', direction: 'rtl' }}
                      formatter={(value) => [`${value} ﷼`, '']}
                    />
                    <Legend />
                    <Bar dataKey="الدخل" fill="#10b981" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="المصروفات" fill="#ef4444" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="occupancy" className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <Card className="border-none shadow-sm">
              <CardHeader>
                <CardTitle>حالة الوحدات العقارية</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px] w-full" dir="ltr">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={occupancyData}
                        cx="50%"
                        cy="50%"
                        innerRadius={80}
                        outerRadius={120}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {occupancyData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => [value, 'وحدة']} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card className="border-none shadow-sm">
              <CardHeader>
                <CardTitle>أبرز العقارات حسب الإشغال</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {['مجمع الرياض السكني', 'برج الياسمين المكتبي'].map((prop, i) => (
                    <div key={i} className="flex flex-col gap-2">
                      <div className="flex justify-between items-center text-sm">
                        <span className="font-medium">{prop}</span>
                        <span className="text-muted-foreground">{90 - (i * 15)}% مؤجر</span>
                      </div>
                      <div className="h-2 w-full bg-muted rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-primary" 
                          style={{ width: `${90 - (i * 15)}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="contracts" className="space-y-6">
          <Card className="border-none shadow-sm">
            <CardHeader>
              <CardTitle>حالة العقود الإيجارية</CardTitle>
              <CardDescription>إحصائيات العقود السارية والمنتهية</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px] w-full" dir="ltr">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart 
                    data={[
                      { name: 'ساري', value: contracts.filter(c=>c.status==='ساري').length },
                      { name: 'قارب على الانتهاء', value: contracts.filter(c=>c.status==='قارب على الانتهاء').length },
                      { name: 'منتهي', value: contracts.filter(c=>c.status==='منتهي').length },
                      { name: 'ملغي', value: contracts.filter(c=>c.status==='ملغي').length },
                    ]} 
                    layout="vertical"
                    margin={{ top: 20, right: 30, left: 40, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" opacity={0.2} horizontal={false} />
                    <XAxis type="number" />
                    <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} />
                    <Tooltip formatter={(value) => [value, 'عقد']} />
                    <Bar dataKey="value" fill="#3b82f6" radius={[0, 4, 4, 0]} barSize={30}>
                      {
                        [0, 1, 2, 3].map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={['#10b981', '#f59e0b', '#ef4444', '#9ca3af'][index]} />
                        ))
                      }
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}