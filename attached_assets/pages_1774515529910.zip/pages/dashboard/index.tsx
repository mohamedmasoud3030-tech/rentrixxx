import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Building2, 
  Users, 
  FileText, 
  Wallet, 
  ArrowUpRight, 
  ArrowDownRight,
  Home,
  Wrench,
  AlertCircle
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useAppStore } from "@/store";
import { useMemo } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

export default function Dashboard() {
  const { properties, units, contracts, receipts, maintenance, invoices } = useAppStore();

  const stats = useMemo(() => {
    const activeContracts = contracts.filter(c => c.status === 'ساري' || c.status === 'قارب على الانتهاء').length;
    const occupiedUnits = units.filter(u => u.status === 'مؤجرة').length;
    const totalUnits = units.length;
    const occupancyRate = totalUnits > 0 ? Math.round((occupiedUnits / totalUnits) * 100) : 0;
    
    // Simplistic current month calc
    const currentMonthReceipts = receipts.reduce((sum, r) => sum + r.amount, 0);

    return [
      {
        title: "العقارات",
        value: properties.length.toString(),
        icon: Building2,
        trend: "+2 من الشهر الماضي",
        trendUp: true,
      },
      {
        title: "الوحدات النشطة",
        value: units.length.toString(),
        icon: Home,
        trend: `${occupancyRate}% نسبة الإشغال`,
        trendUp: occupancyRate > 80,
      },
      {
        title: "العقود السارية",
        value: activeContracts.toString(),
        icon: FileText,
        trend: `${contracts.filter(c => c.status === 'قارب على الانتهاء').length} عقود تنتهي قريباً`,
        trendUp: false,
      },
      {
        title: "إجمالي التحصيلات",
        value: `${currentMonthReceipts.toLocaleString()} ﷼`,
        icon: Wallet,
        trend: "+12% من الشهر الماضي",
        trendUp: true,
      }
    ];
  }, [properties, units, contracts, receipts]);

  const recentContracts = contracts.slice(0, 5);

  const chartData = [
    { name: 'يناير', value: 45000 },
    { name: 'فبراير', value: 52000 },
    { name: 'مارس', value: 38000 },
    { name: 'أبريل', value: 65000 },
    { name: 'مايو', value: 48000 },
    { name: 'يونيو', value: 55000 },
  ];

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div>
        <h1 className="text-3xl font-display font-bold text-foreground">لوحة القيادة</h1>
        <p className="text-muted-foreground mt-1">نظرة عامة على أداء محفظتك العقارية</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat, index) => (
          <Card key={index} className="border-none shadow-sm bg-card hover:shadow-md transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {stat.title}
              </CardTitle>
              <div className="p-2 bg-primary/10 rounded-lg">
                <stat.icon className="h-4 w-4 text-primary" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
              <div className="flex items-center text-xs mt-1">
                {stat.trendUp ? (
                  <ArrowUpRight className="mr-1 h-3 w-3 text-emerald-500" />
                ) : (
                  <ArrowDownRight className="mr-1 h-3 w-3 text-destructive" />
                )}
                <span className={stat.trendUp ? "text-emerald-500" : "text-destructive"}>
                  {stat.trend}
                </span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-4 border-none shadow-sm">
          <CardHeader>
            <CardTitle>التحصيلات الشهرية</CardTitle>
          </CardHeader>
          <CardContent className="pl-2">
            <div className="h-[300px] w-full" dir="ltr">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.3} />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#888888' }} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fill: '#888888' }} tickFormatter={(value) => `${value / 1000}k`} />
                  <Tooltip 
                    cursor={{ fill: 'transparent' }}
                    contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                    formatter={(value) => [`${value} ﷼`, '']}
                  />
                  <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                    {chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={index === chartData.length - 1 ? '#3b82f6' : '#93c5fd'} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        
        <Card className="col-span-3 border-none shadow-sm">
          <CardHeader>
            <CardTitle>تنبيهات هامة</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {contracts.filter(c => c.status === 'قارب على الانتهاء').map((c, i) => (
                <div key={`c-${i}`} className="flex items-start gap-4 p-3 rounded-lg hover:bg-muted/50 transition-colors">
                  <div className="p-2 rounded-full bg-amber-500/10">
                    <FileText className="h-4 w-4 text-amber-500" />
                  </div>
                  <div>
                    <p className="text-sm font-medium">عقد قارب على الانتهاء</p>
                    <p className="text-xs text-muted-foreground mt-1">عقد رقم {c.id}</p>
                  </div>
                </div>
              ))}
              
              {invoices.filter(i => i.status === 'متأخر').map((inv, i) => (
                <div key={`inv-${i}`} className="flex items-start gap-4 p-3 rounded-lg hover:bg-muted/50 transition-colors">
                  <div className="p-2 rounded-full bg-destructive/10">
                    <AlertCircle className="h-4 w-4 text-destructive" />
                  </div>
                  <div>
                    <p className="text-sm font-medium">استحقاق متأخر</p>
                    <p className="text-xs text-muted-foreground mt-1">فاتورة {inv.id} - {inv.amount} ﷼</p>
                  </div>
                </div>
              ))}
              
               {maintenance.filter(m => m.priority === 'عاجل' && m.status !== 'مكتمل').map((m, i) => (
                <div key={`mnt-${i}`} className="flex items-start gap-4 p-3 rounded-lg hover:bg-muted/50 transition-colors">
                  <div className="p-2 rounded-full bg-destructive/10">
                    <Wrench className="h-4 w-4 text-destructive" />
                  </div>
                  <div>
                    <p className="text-sm font-medium">طلب صيانة عاجل</p>
                    <p className="text-xs text-muted-foreground mt-1">{m.title}</p>
                  </div>
                </div>
              ))}
              
              {units.filter(u => u.status === 'شاغرة').slice(0, 2).map((u, i) => (
                <div key={`u-${i}`} className="flex items-start gap-4 p-3 rounded-lg hover:bg-muted/50 transition-colors">
                  <div className="p-2 rounded-full bg-blue-500/10">
                    <Home className="h-4 w-4 text-blue-500" />
                  </div>
                  <div>
                    <p className="text-sm font-medium">وحدة شاغرة</p>
                    <p className="text-xs text-muted-foreground mt-1">{u.number}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-none shadow-sm">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>أحدث العقود</CardTitle>
          <Badge variant="outline" className="font-normal cursor-pointer hover:bg-muted">عرض الكل</Badge>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-right">
              <thead>
                <tr className="border-b text-muted-foreground">
                  <th className="pb-3 font-medium">رقم العقد</th>
                  <th className="pb-3 font-medium">المستأجر</th>
                  <th className="pb-3 font-medium">تاريخ البداية</th>
                  <th className="pb-3 font-medium">تاريخ النهاية</th>
                  <th className="pb-3 font-medium">القيمة (سنوي)</th>
                  <th className="pb-3 font-medium">الحالة</th>
                </tr>
              </thead>
              <tbody>
                {recentContracts.map((contract, i) => {
                  let statusColor = "bg-muted text-muted-foreground";
                  if (contract.status === "ساري") statusColor = "bg-emerald-500/10 text-emerald-500";
                  else if (contract.status === "قارب على الانتهاء") statusColor = "bg-amber-500/10 text-amber-500";
                  
                  return (
                  <tr key={i} className="border-b last:border-0 hover:bg-muted/30 transition-colors">
                    <td className="py-3 font-medium text-primary">{contract.id}</td>
                    <td className="py-3">{contract.tenantId}</td>
                    <td className="py-3 text-muted-foreground">{contract.startDate}</td>
                    <td className="py-3 text-muted-foreground">{contract.endDate}</td>
                    <td className="py-3 font-medium">{contract.amount.toLocaleString()} ﷼</td>
                    <td className="py-3">
                      <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${statusColor}`}>
                        {contract.status}
                      </span>
                    </td>
                  </tr>
                )})}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}