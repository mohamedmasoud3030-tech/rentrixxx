import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Search, Filter, MoreHorizontal, Eye, Edit, Trash, FileText, FileSpreadsheet, CheckCircle2, Clock } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAppStore } from "@/store";
import { Invoice } from "@/types";
import { useToast } from "@/hooks/use-toast";

export default function InvoicesList() {
  const { invoices, contracts, tenants, addInvoice, updateInvoice, cancelInvoice } = useAppStore();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const [isAddOpen, setIsAddOpen] = useState(false);
  const [formData, setFormData] = useState<Partial<Invoice>>({ amount: 0, paid: 0, status: 'مستحق' });

  const getInvoiceDetails = (contractId: string, tenantId: string) => {
    const contract = contracts.find(c => c.id === contractId);
    const tenant = tenants.find(t => t.id === tenantId);
    return {
      contractName: contract ? contract.id : 'غير معروف',
      tenantName: tenant ? tenant.name : 'غير معروف'
    };
  };

  const handleSave = () => {
    if (!formData.contractId || !formData.tenantId || !formData.amount || !formData.dueDate) {
      toast({ title: "خطأ", description: "الرجاء تعبئة جميع الحقول الأساسية", variant: "destructive" });
      return;
    }
    
    addInvoice(formData as Omit<Invoice, 'id'>);
    toast({ title: "نجاح", description: "تم إصدار الفاتورة بنجاح" });
    setIsAddOpen(false);
    setFormData({ amount: 0, paid: 0, status: 'مستحق' });
  };

  const handleCancel = (id: string) => {
    const invoice = invoices.find(i => i.id === id);
    if (invoice?.paid && invoice.paid > 0) {
      toast({ title: "لا يمكن الإلغاء", description: "هذه الفاتورة تحتوي على دفعات محصلة، يجب إلغاء سندات القبض أولاً", variant: "destructive" });
      return;
    }

    if(confirm("هل أنت متأكد من إلغاء هذه الفاتورة؟ الإلغاء إجراء لا يمكن التراجع عنه.")) {
      cancelInvoice(id);
      toast({ title: "تم الإلغاء", description: "تم إلغاء الفاتورة بنجاح" });
    }
  };

  // Helper to pre-fill tenant based on selected contract
  const handleContractChange = (contractId: string) => {
    const contract = contracts.find(c => c.id === contractId);
    if (contract) {
      setFormData({ ...formData, contractId, tenantId: contract.tenantId, amount: contract.amount / (contract.paymentType === 'سنوي' ? 1 : contract.paymentType === 'نصف سنوي' ? 2 : contract.paymentType === 'ربع سنوي' ? 4 : 12) });
    } else {
      setFormData({ ...formData, contractId });
    }
  };

  const stats = {
    totalRemaining: invoices.filter(i => i.status !== 'ملغاة').reduce((sum, i) => sum + (i.amount - i.paid), 0),
    totalCollected: invoices.filter(i => i.status !== 'ملغاة').reduce((sum, i) => sum + i.paid, 0),
    overdue: invoices.filter(i => i.status === 'متأخر').reduce((sum, i) => sum + (i.amount - i.paid), 0),
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground">الاستحقاقات والمطالبات</h1>
          <p className="text-muted-foreground mt-1">متابعة الفواتير والمدفوعات والمبالغ المتأخرة</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="bg-background">
            <FileSpreadsheet className="mr-2 h-4 w-4" />
            تصدير كشف حساب
          </Button>
          
          <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
            <DialogTrigger asChild>
              <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
                <Plus className="mr-2 h-4 w-4" />
                إصدار فاتورة جديدة
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>إصدار فاتورة جديدة</DialogTitle>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="contractId">العقد المرتبط</Label>
                  <Select value={formData.contractId} onValueChange={handleContractChange}>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر العقد" />
                    </SelectTrigger>
                    <SelectContent>
                      {contracts.filter(c => c.status !== 'ملغي').map(contract => (
                        <SelectItem key={contract.id} value={contract.id}>
                          {contract.id} - {tenants.find(t => t.id === contract.tenantId)?.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="tenantId">المستأجر</Label>
                  <Select value={formData.tenantId} onValueChange={(val) => setFormData({...formData, tenantId: val})} disabled>
                    <SelectTrigger className="bg-muted">
                      <SelectValue placeholder="يتم التحديد تلقائياً بناءً على العقد" />
                    </SelectTrigger>
                    <SelectContent>
                      {tenants.map(tenant => (
                        <SelectItem key={tenant.id} value={tenant.id}>{tenant.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="amount">مبلغ الفاتورة</Label>
                    <div className="relative">
                      <Input id="amount" type="number" value={formData.amount || ''} onChange={e => setFormData({...formData, amount: parseInt(e.target.value) || 0})} className="pl-12" />
                      <div className="absolute left-3 top-2.5 text-muted-foreground text-sm">﷼</div>
                    </div>
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="dueDate">تاريخ الاستحقاق</Label>
                    <Input id="dueDate" type="date" value={formData.dueDate || ''} onChange={e => setFormData({...formData, dueDate: e.target.value})} />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddOpen(false)}>إلغاء</Button>
                <Button onClick={handleSave}>إصدار الفاتورة</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="border-none shadow-sm bg-card">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">إجمالي المستحقات</p>
              <p className="text-2xl font-bold">{(stats.totalRemaining + stats.totalCollected).toLocaleString()} ﷼</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm bg-card">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">تم تحصيله</p>
              <p className="text-2xl font-bold text-emerald-500">{stats.totalCollected.toLocaleString()} ﷼</p>
            </div>
            <div className="p-2 bg-emerald-500/10 rounded-lg">
              <CheckCircle2 className="h-5 w-5 text-emerald-500" />
            </div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm bg-card">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">المتبقي للتحصيل</p>
              <p className="text-2xl font-bold text-amber-500">{stats.totalRemaining.toLocaleString()} ﷼</p>
            </div>
            <div className="p-2 bg-amber-500/10 rounded-lg">
              <Clock className="h-5 w-5 text-amber-500" />
            </div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm bg-card">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">مبالغ متأخرة</p>
              <p className="text-2xl font-bold text-destructive">{stats.overdue.toLocaleString()} ﷼</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-none shadow-sm">
        <CardHeader className="pb-3 border-b">
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
            <div className="relative w-full sm:w-96">
              <Search className="absolute right-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="البحث برقم الفاتورة، المستأجر، رقم العقد..."
                className="pr-9 bg-muted/50 border-none"
              />
            </div>
            <div className="flex gap-2 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0">
              <Button variant="secondary" size="sm" className="whitespace-nowrap">الكل</Button>
              <Button variant="ghost" size="sm" className="whitespace-nowrap text-muted-foreground">مدفوع</Button>
              <Button variant="ghost" size="sm" className="whitespace-nowrap text-muted-foreground">مدفوع جزئياً</Button>
              <Button variant="ghost" size="sm" className="whitespace-nowrap text-muted-foreground">مستحق</Button>
              <Button variant="ghost" size="sm" className="whitespace-nowrap text-destructive">متأخر</Button>
              <Button variant="outline" size="icon" className="ml-auto sm:ml-2">
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-right">
              <thead className="bg-muted/30">
                <tr className="border-b">
                  <th className="px-4 py-3 font-medium text-muted-foreground">رقم الفاتورة</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">المستأجر / العقد</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">تاريخ الاستحقاق</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">المبلغ الإجمالي</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">المدفوع</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">المتبقي</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground">الحالة</th>
                  <th className="px-4 py-3 font-medium text-muted-foreground w-[80px]">إجراءات</th>
                </tr>
              </thead>
              <tbody>
                {invoices.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="text-center py-8 text-muted-foreground">لا توجد فواتير</td>
                  </tr>
                ) : invoices.map((invoice) => {
                  let statusColor = "bg-muted text-muted-foreground";
                  if (invoice.status === "مدفوع") statusColor = "bg-emerald-500/10 text-emerald-500";
                  else if (invoice.status === "مدفوع جزئياً") statusColor = "bg-blue-500/10 text-blue-500";
                  else if (invoice.status === "مستحق") statusColor = "bg-amber-500/10 text-amber-500";
                  else if (invoice.status === "متأخر") statusColor = "bg-destructive/10 text-destructive";
                  else if (invoice.status === "ملغاة") statusColor = "bg-muted text-muted-foreground line-through";

                  const details = getInvoiceDetails(invoice.contractId, invoice.tenantId);

                  return (
                    <tr 
                      key={invoice.id} 
                      className={`border-b last:border-0 hover:bg-muted/20 transition-colors cursor-pointer ${invoice.status === 'ملغاة' ? 'opacity-50' : ''}`}
                      onClick={() => setLocation(`/invoices/${invoice.id}`)}
                    >
                      <td className="px-4 py-3 font-medium text-primary">{invoice.id}</td>
                      <td className="px-4 py-3">
                        <div className="flex flex-col">
                          <span className="font-medium">{details.tenantName}</span>
                          <span className="text-xs text-muted-foreground">{details.contractName}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-muted-foreground">{invoice.dueDate}</td>
                      <td className="px-4 py-3 font-medium">{invoice.amount.toLocaleString()} ﷼</td>
                      <td className="px-4 py-3 text-emerald-600">{invoice.paid.toLocaleString()} ﷼</td>
                      <td className="px-4 py-3 font-bold">{(invoice.amount - invoice.paid).toLocaleString()} ﷼</td>
                      <td className="px-4 py-3">
                        <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${statusColor}`}>
                          {invoice.status}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <span className="sr-only">فتح القائمة</span>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem className="cursor-pointer">
                              <Eye className="mr-2 h-4 w-4" />
                              <span>عرض الفاتورة</span>
                            </DropdownMenuItem>
                            {invoice.status !== 'مدفوع' && invoice.status !== 'ملغاة' && (
                              <DropdownMenuItem className="cursor-pointer">
                                <Plus className="mr-2 h-4 w-4" />
                                <span>إضافة سند قبض</span>
                              </DropdownMenuItem>
                            )}
                            <DropdownMenuItem className="cursor-pointer">
                              <FileSpreadsheet className="mr-2 h-4 w-4" />
                              <span>طباعة PDF</span>
                            </DropdownMenuItem>
                            {invoice.status !== 'ملغاة' && (
                              <DropdownMenuItem className="cursor-pointer text-destructive" onClick={() => handleCancel(invoice.id)}>
                                <Trash className="mr-2 h-4 w-4" />
                                <span>إلغاء الفاتورة</span>
                              </DropdownMenuItem>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}