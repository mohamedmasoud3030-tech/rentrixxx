import { useParams, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, User, Home, MapPin, Calendar, CreditCard, FileText, CheckCircle2, AlertCircle, Printer, Download, Plus } from "lucide-react";
import { useAppStore } from "@/store";

export default function InvoiceDetails() {
  const { id } = useParams();
  const { invoices, contracts, tenants, units, properties, receipts } = useAppStore();
  
  const invoice = invoices.find(i => i.id === id);
  
  if (!invoice) {
    return (
      <div className="flex flex-col items-center justify-center h-full space-y-4">
        <h2 className="text-2xl font-bold">الفاتورة غير موجودة</h2>
        <Link href="/invoices"><Button variant="outline">العودة لقائمة الفواتير</Button></Link>
      </div>
    );
  }

  const contract = contracts.find(c => c.id === invoice.contractId);
  const tenant = tenants.find(t => t.id === invoice.tenantId);
  const unit = contract ? units.find(u => u.id === contract.unitId) : null;
  const property = unit ? properties.find(p => p.id === unit.propertyId) : null;
  
  // Get receipts associated with this invoice
  const invoiceReceipts = receipts.filter(r => r.invoiceId === id && r.status !== 'ملغي');
  const remainingAmount = Math.max(0, invoice.amount - invoice.paid);

  let statusColor = "bg-muted text-muted-foreground";
  if (invoice.status === "مدفوع") statusColor = "bg-emerald-500/10 text-emerald-500 border-emerald-200";
  else if (invoice.status === "مدفوع جزئياً") statusColor = "bg-blue-500/10 text-blue-500 border-blue-200";
  else if (invoice.status === "مستحق") statusColor = "bg-amber-500/10 text-amber-500 border-amber-200";
  else if (invoice.status === "متأخر") statusColor = "bg-destructive/10 text-destructive border-destructive/20";
  else if (invoice.status === "ملغاة") statusColor = "bg-muted text-muted-foreground border-border line-through";

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-4">
          <Link href="/invoices">
            <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
              <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-display font-bold text-foreground">فاتورة رقم: {invoice.id}</h1>
            <div className="flex items-center gap-2 mt-1">
              <Badge variant="outline" className={`font-normal ${statusColor}`}>
                {invoice.status}
              </Badge>
              <span className="text-muted-foreground text-sm">•</span>
              <span className="text-muted-foreground text-sm">تاريخ الاستحقاق: {invoice.dueDate}</span>
            </div>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="bg-background">
            <Printer className="mr-2 h-4 w-4" />
            طباعة الفاتورة
          </Button>
          <Button variant="outline" className="bg-background">
            <Download className="mr-2 h-4 w-4" />
            تحميل PDF
          </Button>
          {invoice.status !== 'مدفوع' && invoice.status !== 'ملغاة' && (
            <Link href={`/receipts?invoice=${invoice.id}`}>
              <Button className="bg-primary text-primary-foreground">
                <Plus className="mr-2 h-4 w-4" />
                سند قبض
              </Button>
            </Link>
          )}
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-6">
          <Card className="border-none shadow-sm">
            <CardHeader className="pb-3 border-b">
              <CardTitle>تفاصيل الفاتورة</CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="flex flex-col md:flex-row gap-8 justify-between">
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">مطلوبة من:</p>
                    {tenant ? (
                      <Link href={`/tenants/${tenant.id}`} className="font-bold text-lg hover:underline block">
                        {tenant.name}
                      </Link>
                    ) : (
                      <span className="font-medium">غير معروف</span>
                    )}
                    {tenant && <p className="text-sm text-muted-foreground mt-1" dir="ltr">{tenant.phone}</p>}
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">تفاصيل العقد:</p>
                    {contract ? (
                      <Link href={`/contracts/${contract.id}`} className="font-medium text-primary hover:underline block">
                        عقد رقم {contract.id}
                      </Link>
                    ) : (
                      <span className="text-sm">غير محدد</span>
                    )}
                  </div>
                </div>

                <div className="space-y-4 md:text-left">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">العين المؤجرة:</p>
                    {unit && property ? (
                      <div>
                        <Link href={`/units/${unit.id}`} className="font-medium hover:underline block">
                          {unit.number} ({unit.type})
                        </Link>
                        <Link href={`/properties/${property.id}`} className="text-sm text-muted-foreground hover:underline">
                          {property.name}
                        </Link>
                      </div>
                    ) : (
                      <span className="font-medium">غير معروف</span>
                    )}
                  </div>
                </div>
              </div>

              <div className="mt-8">
                <table className="w-full text-sm">
                  <thead className="bg-muted/30">
                    <tr className="border-b">
                      <th className="px-4 py-3 font-medium text-right text-muted-foreground">البند</th>
                      <th className="px-4 py-3 font-medium text-left text-muted-foreground">القيمة</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b">
                      <td className="px-4 py-4">
                        <p className="font-medium">دفعة إيجارية</p>
                        <p className="text-xs text-muted-foreground mt-1">حسب العقد رقم {contract?.id}</p>
                      </td>
                      <td className="px-4 py-4 text-left font-medium">{invoice.amount.toLocaleString()} ﷼</td>
                    </tr>
                    <tr>
                      <td className="px-4 py-3 font-bold text-lg">الإجمالي</td>
                      <td className="px-4 py-3 text-left font-bold text-lg text-primary">{invoice.amount.toLocaleString()} ﷼</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-sm">
            <CardHeader className="pb-3 border-b flex flex-row items-center justify-between">
              <CardTitle>المدفوعات وسندات القبض</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              {invoiceReceipts.length === 0 ? (
                <div className="text-center py-6 text-muted-foreground text-sm">
                  لا توجد مدفوعات مسجلة على هذه الفاتورة
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm text-right">
                    <thead className="bg-muted/30">
                      <tr className="border-b">
                        <th className="px-4 py-3 font-medium text-muted-foreground">رقم السند</th>
                        <th className="px-4 py-3 font-medium text-muted-foreground">تاريخ الدفع</th>
                        <th className="px-4 py-3 font-medium text-muted-foreground">طريقة الدفع</th>
                        <th className="px-4 py-3 font-medium text-muted-foreground">الرقم المرجعي</th>
                        <th className="px-4 py-3 font-medium text-left text-muted-foreground">المبلغ المحصل</th>
                      </tr>
                    </thead>
                    <tbody>
                      {invoiceReceipts.map(receipt => (
                        <tr key={receipt.id} className="border-b last:border-0 hover:bg-muted/20">
                          <td className="px-4 py-3 font-medium">
                            <Link href={`/receipts/${receipt.id}`} className="text-primary hover:underline">
                              {receipt.id}
                            </Link>
                          </td>
                          <td className="px-4 py-3 text-muted-foreground">{receipt.date}</td>
                          <td className="px-4 py-3">{receipt.method}</td>
                          <td className="px-4 py-3 text-muted-foreground" dir="ltr">{receipt.reference || '-'}</td>
                          <td className="px-4 py-3 font-bold text-emerald-600 text-left">{receipt.amount.toLocaleString()} ﷼</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="border-none shadow-sm bg-card h-fit sticky top-6">
            <CardHeader className="pb-3 border-b">
              <CardTitle>الخلاصة المالية</CardTitle>
            </CardHeader>
            <CardContent className="pt-4 space-y-4">
              <div className="flex justify-between items-center text-sm">
                <span className="text-muted-foreground">قيمة الفاتورة:</span>
                <span className="font-bold">{invoice.amount.toLocaleString()} ﷼</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-muted-foreground">المبلغ المحصل:</span>
                <span className="font-medium text-emerald-600">{invoice.paid.toLocaleString()} ﷼</span>
              </div>
              <div className="pt-3 border-t flex justify-between items-center">
                <span className="font-bold">المتبقي للدفع:</span>
                <span className={`font-bold text-xl ${remainingAmount > 0 ? 'text-destructive' : 'text-emerald-600'}`}>
                  {remainingAmount.toLocaleString()} ﷼
                </span>
              </div>
              
              {remainingAmount > 0 && invoice.status !== 'ملغاة' && (
                <div className="pt-4 mt-2">
                  <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
                    <div className="flex items-start gap-2 text-amber-800">
                      <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
                      <div className="text-sm">
                        <p className="font-bold mb-1">مطالبة مفتوحة</p>
                        <p className="text-xs">يرجى متابعة التحصيل مع المستأجر قبل تاريخ الاستحقاق لتجنب التأخير.</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              
              {remainingAmount === 0 && invoice.status === 'مدفوع' && (
                <div className="pt-4 mt-2">
                  <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3 flex items-center justify-center gap-2 text-emerald-700">
                    <CheckCircle2 className="h-5 w-5" />
                    <span className="font-bold">تم سداد الفاتورة بالكامل</span>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}